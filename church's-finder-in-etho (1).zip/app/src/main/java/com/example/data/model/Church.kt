package com.example.data.model

enum class ReligiousTradition {
    ORTHODOX,    // የኢትዮጵያ ኦርቶዶክስ ተዋሕዶ
    PROTESTANT,  // ፕሮቴስታንት / ወንጌላውያን
    ISLAM        // እስልምና / መስጊድ
}

data class ClergyContact(
    val title: String,        // e.g. የደብሩ አስተዳዳሪ / ፓስተር / ዋና ኢማም
    val name: String,         // e.g. መልአከ ሰላም ቆሞስ አባ ዘርዓ ቡሩክ / ፓስተር ታደለ / ሸይኽ ሙሐመድ
    val phoneNumber: String,  // e.g. +251 91 123 4567
    val roleAmharic: String   // e.g. አስተዳደር / መንፈሳዊ አገልግሎት / ኢማም
)

data class LiturgyProgram(
    val titleAmharic: String,      // e.g. የሰንበት ጧት ቅዳሴ / የእሑድ አምልኮ / የጁምዓ ሰላት
    val timeAmharic: String,       // e.g. 12:00 - 3:00 / 3:30 - 6:30 / 6:30 - 8:00
    val dayOfWeek: String,         // e.g. እሑድ / አርብ / በየቀኑ
    val description: String,       // ዝርዝር ማብራሪያ
    val type: ProgramType
)

enum class ProgramType {
    LITURGY,        // ቅዳሴ / ዋና አምልኮ
    PRAYER_SERVICE, // የጸሎት መርሐ ግብር / የወቅቱ ሰላቶች
    MAHLET,         // ማህሌት
    KIDAN,          // ኪዳን
    JUMMAH,         // የጁምዓ ሰላት
    SUNDAY_SCHOOL   // ሰንበት ትምህርት ቤት / መድረሳ
}

data class TabotFeast(
    val saintNameAmharic: String,  // e.g. ቅዱስ ጊዮርጊስ / ዓመታዊ ኮንፈረንስ / ዒድ አል-ፈጥር
    val ethiopianDate: String,     // e.g. ጥር 23 / ኅዳር / ረመዳን መጨረሻ
    val gregorianDateApprox: String, // e.g. Feb 1 / Nov / May
    val feastTitle: String,        // e.g. ዓመታዊ የንግሥ በዓል / የትንሣኤ በዓል / ታላቅ የዒድ ሰላት
    val description: String
)

data class SundaySchoolProgram(
    val title: String,            // e.g. የሰንበት ት/ቤት / የመጽሐፍ ቅዱስ ጥናት / የቁርኣን ቂርዓት
    val schedule: String,         // e.g. ቅዳሜ ከቀኑ 8:00 - 11:00
    val leaderContact: String? = null
)

data class Church(
    val id: String,
    val nameAmharic: String,
    val nameEnglish: String,
    val tradition: ReligiousTradition = ReligiousTradition.ORTHODOX,
    val denominationOrType: String = "ኦርቶዶክስ ተዋሕዶ", // e.g. መካነ ኢየሱስ፣ ቃለ ሕይወት፣ አህለሱና መስጊድ
    val patronSaint: String = "",       // ጊዮርጊስ፣ ማርያም፣ ሥላሴ or leader/founder
    val dioceseAmharic: String,         // ሀገረ ስብከት / ሲኖዶስ / የክልል መጅሊስ
    val subCityOrZone: String,          // ክፍለ ከተማ / ዞን
    val city: String,                   // አዲስ አበባ፣ ላሊበላ፣ ጎንደር፣ አክሱም፣ ሐረር፣ ሐዋሳ
    val isHistoricOrMonastery: Boolean = false, // ታሪካዊ ቦታ / ገዳም
    val isCathedral: Boolean = false,   // ካቴድራል / ታላቅ ማዕከል
    val centuryBuilt: String = "",           // የተመሠረተበት ዘመን
    val descriptionAmharic: String,     // ታሪክና ገለጻ
    val latitude: Double,
    val longitude: Double,
    val addressAmharic: String,
    val clergyContacts: List<ClergyContact> = emptyList(),
    val weeklyPrograms: List<LiturgyProgram> = emptyList(),
    val annualFeasts: List<TabotFeast> = emptyList(),
    val sundaySchoolPrograms: List<SundaySchoolProgram> = emptyList(),
    val localImageDrawable: Int? = null,
    val distanceKmAddis: Double = 0.0,
    val travelTipAmharic: String = ""
)
