package com.example.data.repository

import com.example.R
import com.example.data.model.Church
import com.example.data.model.ClergyContact
import com.example.data.model.LiturgyProgram
import com.example.data.model.ProgramType
import com.example.data.model.ReligiousTradition
import com.example.data.model.SundaySchoolProgram
import com.example.data.model.TabotFeast
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class ChurchRepository {

    private val allWorshipPlaces = listOf(
        // === ETHIOPIAN ORTHODOX TEWAHEDO CHURCHES ===
        Church(
            id = "lalibela_giyorgis",
            nameAmharic = "ቤተ ጊዮርጊስ (ላሊበላ)",
            nameEnglish = "Bete Giyorgis (Church of Saint George, Lalibela)",
            tradition = ReligiousTradition.ORTHODOX,
            denominationOrType = "ኦርቶዶክስ ተዋሕዶ",
            patronSaint = "ጊዮርጊስ",
            dioceseAmharic = "ሰሜን ወሎ (ላሊበላ)",
            subCityOrZone = "ላሊበላ ከተማ",
            city = "ላሊበላ",
            isHistoricOrMonastery = true,
            centuryBuilt = "12ኛው መቶ ክፍለ ዘመን (በቅዱስ ላሊበላ)",
            descriptionAmharic = "ከአንድ ወጥ ቀይ እሳተ ገሞራ አለት ተፈልፍሎ የተሠራው የመስቀል ቅርጽ ያለው አስደናቂው ቤተ ጊዮርጊስ። በዩኔስኮ የዓለም ቅርስነት የተመዘገበ ሲሆን፤ በቅዱስ ላሊበላ ዘመነ መንግሥት በሰማዕቱ በቅዱስ ጊዮርጊስ ረዳትነት የታነጸ የኢትዮጵያ ኦርቶዶክስ ተዋሕዶ ተምሳሌት ነው።",
            latitude = 12.0322,
            longitude = 39.0416,
            addressAmharic = "ላሊበላ፣ ሰሜን ወሎ፣ አማራ ክልል",
            clergyContacts = listOf(
                ClergyContact("የደብሩ አስተዳዳሪ", "መልአከ ሰላም ቆሞስ አባ ተክለ ማርያም", "+251 91 334 1122", "አስተዳደር"),
                ClergyContact("ዋና ጸሐፊ", "ቀሲስ ገብረ ሥላሴ ደስታ", "+251 91 876 5432", "ጽሕፈት ቤት")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የዘወትር የጧት ኪዳን", "11:00 - 12:30 (ጧት)", "በየቀኑ", "የካህናትና ምእመናን የኪዳን ጸሎት", ProgramType.KIDAN),
                LiturgyProgram("የሰንበት ቅዳሴ (ቅዳሜና እሑድ)", "12:00 - 3:00 (ጧት)", "ቅዳሜ እና እሑድ", "ሙሉ የቅዳሴ ሥርዓትና ቃለ እግዚአብሔር", ProgramType.LITURGY),
                LiturgyProgram("ዓመታዊና ወርሃዊ ማህሌት", "7:00 - 11:30 (ሌሊት)", "በየወሩ 23", "በያሬዳዊ ዜማ የሚቀርብ ምስጋና", ProgramType.MAHLET)
            ),
            annualFeasts = listOf(
                TabotFeast("ቅዱስ ጊዮርጊስ (ልደቱ)", "ጥር 23", "የካቲት 1 ገደማ", "ዓመታዊ ታላቅ የንግሥ በዓል", "በአሥር ሺዎች የሚቆጠሩ የሀገር ውስጥና የውጭ ምእመናን ታቦተ ሕጉን የሚያጅቡበት"),
                TabotFeast("ቅዱስ ጊዮርጊስ (ዕረፍቱ)", "ሚያዝያ 23", "ግንቦት 1 ገደማ", "የዕረፍቱ መታሰቢያ ንግሥ", "ታቦተ ሕጉ ወጥቶ ሜዳ ላይ የሚያድርበትና የሚያበራበት ታላቅ በዓል")
            ),
            sundaySchoolPrograms = listOf(
                SundaySchoolProgram("ደብረ ሮሃ ሰንበት ት/ቤት", "ዘወትር እሑድ ከቀኑ 8:00", "+251 91 334 1122")
            ),
            localImageDrawable = R.drawable.img_lalibela,
            distanceKmAddis = 642.0,
            travelTipAmharic = "በአውሮፕላን ወደ ላሊበላ አየር ማረፊያ ወይም በመኪና በወልዲያ በኩል መጓዝ ይቻላል። ጥር 23 በዓል ወቅት አስቀድሞ ማረፊያ መያዝ ይመረጣል።"
        ),
        Church(
            id = "axum_tsion",
            nameAmharic = "ርዕሰ አድባራት ወገዳማት አክሱም ጽዮን ማርያም",
            nameEnglish = "Church of Our Lady Mary of Zion (Axum Tsion)",
            tradition = ReligiousTradition.ORTHODOX,
            denominationOrType = "ኦርቶዶክስ ተዋሕዶ",
            patronSaint = "ማርያም",
            dioceseAmharic = "ማዕከላዊ ትግራይ (አክሱም)",
            subCityOrZone = "አክሱም ማዕከል",
            city = "አክሱም",
            isHistoricOrMonastery = true,
            isCathedral = true,
            centuryBuilt = "4ኛው መቶ ክፍለ ዘመን (በአብርሃና አፅብሃ)",
            descriptionAmharic = "የኢትዮጵያ ኦርቶዶክስ ተዋሕዶ ቤተክርስቲያን ቀዳሚትና ርዕሰ አድባራት። አስርቱ ቃላት የተጻፈበት የመጀመሪያው ጽላተ ኪዳን (ታቦተ ጽዮን) የሚያርፍባት ቅድስት ቦታ። በአክሱማዊያን ሥልጣኔ ዘመን የታነጸች መንፈሳዊ ማዕከል ናት።",
            latitude = 14.1299,
            longitude = 38.7196,
            addressAmharic = "አክሱም ከተማ፣ ትግራይ ክልል",
            clergyContacts = listOf(
                ClergyContact("የአክሱም ጽዮን ንቡረ እድ", "መልአከ ብርሃናት ቆሞስ አባ ዘርዓ ዳዊት", "+251 91 472 8899", "የመንበረ ጽዮን ሓላፊ"),
                ClergyContact("የዕቃ ቤት ተጠሪ ካህን", "ቀሲስ ወልደ ሩፋኤል", "+251 91 433 2211", "ጥንታዊ ንዋየ ቅድሳት")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የዘወትር ቅዳሴ", "12:00 - 2:30 (ጧት)", "በየቀኑ", "የማኅሌትና የቅዳሴ ጸሎት", ProgramType.LITURGY),
                LiturgyProgram("የጽዮን ማህሌት", "6:00 - 11:30 (ሌሊት)", "በየወሩ 21", "የእመቤታችን ምስጋና ማህሌት", ProgramType.MAHLET)
            ),
            annualFeasts = listOf(
                TabotFeast("ጽዮን ማርያም (ኅዳር ጽዮን)", "ኅዳር 21", "ኅዳር 30 ገደማ", "ዋናው ዓመታዊ የጽዮን በዓለ ንግሥ", "ከመላው ዓለም ምእመናን የሚሰበሰቡበት፤ ታቦተ ጽዮን በታላቅ ክብር የሚወደስበት ዕለት")
            ),
            sundaySchoolPrograms = listOf(
                SundaySchoolProgram("መንበረ ጽዮን ሰንበት ት/ቤት", "ቅዳሜና እሑድ ከሰዓት", "+251 91 472 8899")
            ),
            localImageDrawable = R.drawable.img_axum,
            distanceKmAddis = 1024.0,
            travelTipAmharic = "በአውሮፕላን አክሱም ዮሐንስ አራተኛ አየር ማረፊያ መድረስ ይቻላል። የታሪክ ሙዚየሙና የድንጋይ ሐውልቶቹ በቅርብ ርቀት ይገኛሉ።"
        ),
        Church(
            id = "addis_selassie",
            nameAmharic = "መንበረ ፀባዖት ቅድስት ሥላሴ ካቴድራል",
            nameEnglish = "Holy Trinity Cathedral (Kidist Selassie, Addis Ababa)",
            tradition = ReligiousTradition.ORTHODOX,
            denominationOrType = "ኦርቶዶክስ ተዋሕዶ",
            patronSaint = "ሥላሴ",
            dioceseAmharic = "አዲስ አበባ",
            subCityOrZone = "አራዳ ክፍለ ከተማ",
            city = "አዲስ አበባ",
            isHistoricOrMonastery = true,
            isCathedral = true,
            centuryBuilt = "1924 - 1936 ዓ.ም",
            descriptionAmharic = "በአዲስ አበባ ከተማ እምብርት የሚገኘው ታላቁ መንበረ ፀባዖት ቅድስት ሥላሴ ካቴድራል፤ የኢትዮጵያ ፓትርያርኮች ማዕረገ ጵጵስና የሚሾሙበት፣ የሀገር መሪዎችና ጀግኖች ያረፉበት፣ እጅግ ውብ የድንጋይ ቅርጽና የቀለም መስታወት ስዕላት ያሉት ብሔራዊ ቅርስ ነው።",
            latitude = 9.0315,
            longitude = 38.7661,
            addressAmharic = "አራዳ ክፍለ ከተማ፣ ፓርላማ ፊት ለፊት፣ አዲስ አበባ",
            clergyContacts = listOf(
                ClergyContact("የካቴድራሉ አስተዳዳሪ", "መልአከ ኃይል ቆሞስ አባ ኃይለ ማርያም", "+251 11 123 3555", "ዋና አስተዳደር")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የዘወትር ቅዳሴ", "12:00 - 2:00 (ጧት)", "ከሰኞ እስከ አርብ", "የካህናትና ምእመናን ቅዳሴ", ProgramType.LITURGY),
                LiturgyProgram("የሰንበት ጧት ቅዳሴ", "11:30 - 3:00 (ጧት)", "ቅዳሜ እና እሑድ", "የካቴድራሉ አባቶችና ምእመናን ማኅበር", ProgramType.LITURGY)
            ),
            annualFeasts = listOf(
                TabotFeast("ቅድስት ሥላሴ (ጥር ሥላሴ)", "ጥር 7", "ጥር 16 ገደማ", "ዓመታዊ ታላቅ የንግሥ በዓል", "ብፁዕ ወቅዱስ ፓትርያርክና ሊቃነ ጳጳሳት የሚገኙበት ታላቅ በዓል")
            ),
            sundaySchoolPrograms = listOf(
                SundaySchoolProgram("መንበረ ፀባዖት ሰንበት ት/ቤት", "ቅዳሜና እሑድ ከቀኑ 8:30", "+251 11 123 3555")
            ),
            localImageDrawable = R.drawable.img_addis_selassie,
            distanceKmAddis = 0.0,
            travelTipAmharic = "በአዲስ አበባ ከተማ መሃል ከአራት ኪሎ አጠገብ በታክሲም ሆነ በግል መኪና በቀላሉ መድረስ ይቻላል።"
        ),
        Church(
            id = "gondar_selassie",
            nameAmharic = "ደብረ ብርሃን ሥላሴ (ጎንደር)",
            nameEnglish = "Debre Berhan Selassie Church (Gondar)",
            tradition = ReligiousTradition.ORTHODOX,
            denominationOrType = "ኦርቶዶክስ ተዋሕዶ",
            patronSaint = "ሥላሴ",
            dioceseAmharic = "ማዕከላዊ ጎንደር",
            subCityOrZone = "ፋሲል ክፍለ ከተማ",
            city = "ጎንደር",
            isHistoricOrMonastery = true,
            centuryBuilt = "17ኛው መቶ ክፍለ ዘመን (በዐፄ ኢያሱ 1ኛ)",
            descriptionAmharic = "በ104ቱ የክንፈ ኪሩቤል (የመላእክት) ስዕላት የታወቀው የደብረ ብርሃን ሥላሴ ቤተክርስቲያን። በደርቡሾች ወረራ ወቅት በንብ መንጋ ተአምር የዳነ ታሪካዊና አስደናቂ የስዕል ጥበብ ማዕከል ነው።",
            latitude = 12.6117,
            longitude = 37.4816,
            addressAmharic = "ጎንደር ከተማ፣ ማዕከላዊ ጎንደር",
            clergyContacts = listOf(
                ClergyContact("የደብሩ አስተዳዳሪ", "መልአከ ገነት አባ ኪዳነ ማርያም", "+251 91 822 3344", "አስተዳደር")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የዘወትር ኪዳን", "11:00 - 12:30 (ጧት)", "በየቀኑ", "የካህናት ጸሎተ ኪዳን", ProgramType.KIDAN),
                LiturgyProgram("የሰንበት ቅዳሴ", "12:00 - 3:00 (ጧት)", "እሑድ", "የሰንበት ማኅበር ቅዳሴ", ProgramType.LITURGY)
            ),
            annualFeasts = listOf(
                TabotFeast("ቅድስት ሥላሴ ንግሥ", "ጥር 7", "ጥር 16 ገደማ", "ዓመታዊ ንግሥ", "የጎንደርና የአካባቢው ምእመናን በድምቀት የሚያከብሩት")
            ),
            sundaySchoolPrograms = emptyList(),
            localImageDrawable = null,
            distanceKmAddis = 725.0,
            travelTipAmharic = "ከፋሲል ግቢ በስተሰሜን ምሥራቅ 2 ኪሎ ሜትር ርቀት ላይ ይገኛል።"
        ),
        Church(
            id = "debre_libanos",
            nameAmharic = "ደብረ ሊባኖስ ገዳም (ጻድቁ አቡነ ተክለ ሃይማኖት)",
            nameEnglish = "Debre Libanos Monastery",
            tradition = ReligiousTradition.ORTHODOX,
            denominationOrType = "ኦርቶዶክስ ተዋሕዶ",
            patronSaint = "ተክለ ሃይማኖት",
            dioceseAmharic = "ሰሜን ሸዋ (ደብረ ሊባኖስ)",
            subCityOrZone = "ደብረ ሊባኖስ ወረዳ",
            city = "ደብረ ሊባኖስ",
            isHistoricOrMonastery = true,
            centuryBuilt = "13ኛው መቶ ክፍለ ዘመን (በአቡነ ተክለ ሃይማኖት)",
            descriptionAmharic = "በኢትዮጵያ ታላቁ የገዳማት መፍለቂያ የሆነው ታሪካዊው ደብረ ሊባኖስ ገዳም። ጻድቁ አቡነ ተክለ ሃይማኖት ለአንድ እግራቸው በቆሙበት ጸሎትና ተጋድሎ የታወቀ፤ በፈዋሽ ፀበሉ የሚታወቅ ቅዱስ ገዳም ነው።",
            latitude = 9.7144,
            longitude = 38.8544,
            addressAmharic = "ደብረ ሊባኖስ፣ ሰሜን ሸዋ፣ ኦሮሚያ ክልል",
            clergyContacts = listOf(
                ClergyContact("የገዳሙ መጋቢ", "ቆሞስ አባ ዘየሐንስ", "+251 91 199 4433", "ገዳም አስተዳደር")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የዕለት ቅዳሴ", "12:00 - 2:30 (ጧት)", "በየቀኑ", "የዕለቱ ቅዳሴ", ProgramType.LITURGY)
            ),
            annualFeasts = listOf(
                TabotFeast("አቡነ ተክለ ሃይማኖት (ዕረፍታቸው)", "ነሐሴ 24", "ጳጉሜን 1 ገደማ", "ዓመታዊ ታላቅ ንግሥ", "በመቶ ሺዎች የሚቆጠሩ ምእመናን በእግራቸው ጭምር ተጉዘው የሚሳተፉበት")
            ),
            sundaySchoolPrograms = emptyList(),
            localImageDrawable = null,
            distanceKmAddis = 105.0,
            travelTipAmharic = "ከአዲስ አበባ በጎጃም መስመር በ105 ኪሎ ሜትር ላይ ይገኛል። የቀን ጉዞ ለማድረግ በጣም ምቹ ነው።"
        ),
        Church(
            id = "bole_medhanealem",
            nameAmharic = "ቦሌ ደብረ ሳሌም መድኃኔዓለም ካቴድራል",
            nameEnglish = "Bole Medhane Alem Cathedral (Addis Ababa)",
            tradition = ReligiousTradition.ORTHODOX,
            denominationOrType = "ኦርቶዶክስ ተዋሕዶ",
            patronSaint = "መድኃኔዓለም",
            dioceseAmharic = "አዲስ አበባ",
            subCityOrZone = "ቦሌ ክፍለ ከተማ",
            city = "አዲስ አበባ",
            isHistoricOrMonastery = false,
            isCathedral = true,
            centuryBuilt = "1990ዎቹ ዓ.ም",
            descriptionAmharic = "በኢትዮጵያና በአፍሪካ ግዙፍ ከሚባሉት ካቴድራሎች አንዱ የሆነው ቦሌ መድኃኔዓለም። በዘመናዊና ባህላዊ አሠራር የተዋሃደ ታላቅ መንፈሳዊ ማዕከል ነው።",
            latitude = 8.9984,
            longitude = 38.7877,
            addressAmharic = "ቦሌ መድኃኔዓለም አደባባይ አጠገብ፣ አዲስ አበባ",
            clergyContacts = listOf(
                ClergyContact("የካቴድራሉ አስተዳዳሪ", "ሊቀ ስዩማን ቆሞስ አባ ዘካርያስ", "+251 11 662 0101", "ዋና ጽሕፈት ቤት")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የሰንበት ቅዳሴ", "11:30 - 3:00 (ጧት)", "ቅዳሜ እና እሑድ", "የካቴድራሉ ሰፊ ምእመናን ቅዳሴ", ProgramType.LITURGY)
            ),
            annualFeasts = listOf(
                TabotFeast("መድኃኔዓለም (ጥቅምት መድኃኔዓለም)", "ጥቅምት 27", "ኅዳር 5 ገደማ", "ዓመታዊ ታላቅ ንግሥ", "በመቶ ሺህ የሚቆጠሩ ምእመናን የሚታደሙበት ዓመታዊ በዓል")
            ),
            sundaySchoolPrograms = emptyList(),
            localImageDrawable = null,
            distanceKmAddis = 0.0,
            travelTipAmharic = "በቦሌ ዓለም አቀፍ አውሮፕላን ማረፊያ አቅራቢያ የሚገኝ ሲሆን በታክሲ በቀላሉ መድረስ ይቻላል።"
        ),

        // === PROTESTANT / EVANGELICAL CHURCHES ===
        Church(
            id = "eecmy_central",
            nameAmharic = "የኢትዮጵያ ወንጌላዊት ቤተክርስቲያን መካነ ኢየሱስ (ማዕከላዊ ሲኖዶስ)",
            nameEnglish = "Ethiopian Evangelical Church Mekane Yesus (Central Synod Church)",
            tradition = ReligiousTradition.PROTESTANT,
            denominationOrType = "መካነ ኢየሱስ (EECMY)",
            patronSaint = "መካነ ኢየሱስ",
            dioceseAmharic = "አዲስ አበባ ማዕከላዊ ሲኖዶስ",
            subCityOrZone = "አራዳ ክፍለ ከተማ",
            city = "አዲስ አበባ",
            isHistoricOrMonastery = true,
            isCathedral = true,
            centuryBuilt = "1920ዎቹ - 1959 ዓ.ም",
            descriptionAmharic = "በኢትዮጵያ ትልቁ የወንጌላውያን አብያተ ክርስቲያናት ማኅበር የሆነው የመካነ ኢየሱስ ማዕከላዊ ቤተክርስቲያን። በአምስት ኪሎ አቅራቢያ የሚገኝ ጥንታዊ፣ ዘመናዊና ታሪካዊ የአምልኮ አዳራሽ ሲሆን፤ በወንጌል ስብከትና በማኅበራዊ አገልግሎት የታወቀ ነው።",
            latitude = 9.0435,
            longitude = 38.7610,
            addressAmharic = "አምስት ኪሎ፣ አራዳ ክፍለ ከተማ፣ አዲስ አበባ",
            clergyContacts = listOf(
                ClergyContact("ዋና መጋቢ (Senior Pastor)", "ፓስተር ዶ/ር ዮናስ ይገዙ", "+251 11 155 3280", "ዋና ፓስተር"),
                ClergyContact("ረዳት ፓስተር", "ፓስተር ጌታቸው ደበበ", "+251 91 140 2233", "የስብከትና የማስተማር አገልግሎት"),
                ClergyContact("የወጣቶች መምሪያ ተጠሪ", "ወጣት ዳዊት አበበ", "+251 91 188 4455", "ወጣቶችና አምልኮ")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የእሑድ ጠዋት የመጀመሪያ አምልኮ", "2:30 - 4:30 (ጧት)", "እሑድ", "የምስጋና፣ የመዝሙርና የቃል አገልግሎት", ProgramType.LITURGY),
                LiturgyProgram("የእሑድ ሁለተኛ አምልኮ (ዋና ፕሮግራም)", "4:45 - 7:00 (ጧት)", "እሑድ", "ሙሉ የምእመናን አምልኮና የስብከት ጊዜ", ProgramType.LITURGY),
                LiturgyProgram("የረቡዕ የጸሎትና የመጽሐፍ ቅዱስ ጥናት", "11:30 - 1:30 (ማታ)", "ረቡዕ", "የምእመናን የሕብረት ጸሎትና ትምህርት", ProgramType.PRAYER_SERVICE),
                LiturgyProgram("የወጣቶች ህብረት ፕሮግራም", "8:30 - 11:30 (ከሰዓት)", "ቅዳሜ", "የወጣቶች አምልኮና ሥልጠና", ProgramType.SUNDAY_SCHOOL)
            ),
            annualFeasts = listOf(
                TabotFeast("የትንሣኤ (Easter) ታላቅ ጉባኤ", "መጋቢት / ሚያዝያ", "March / April", "ዓመታዊ የትንሣኤ አምልኮ", "የኢየሱስ ክርስቶስን ትንሣኤ በደማቅ ዝማሬና ምስጋና የሚከበርበት"),
                TabotFeast("የገና (Christmas) በዓል", "ታኅሣሥ 29", "January 7", "የልደት በዓል አምልኮ", "የክርስቶስ ልደት በዓል ምስጋና"),
                TabotFeast("ዓመታዊ የወንጌል ኮንፈረንስ", "ጥቅምት", "October", "ታላቅ መንፈሳዊ ኮንፈረንስ", "ከየአካባቢው የተውጣጡ ምእመናን የሚሳተፉበት")
            ),
            sundaySchoolPrograms = listOf(
                SundaySchoolProgram("የሕፃናት ሰንበት ት/ቤት (Sunday School)", "ዘወትር እሑድ ከጧቱ 3:00 - 6:00", "+251 11 155 3280"),
                SundaySchoolProgram("የወጣቶች ኮርስና የመጽሐፍ ቅዱስ ትምህርት", "ቅዳሜ ከቀኑ 9:00", "+251 91 188 4455")
            ),
            localImageDrawable = R.drawable.img_mekane_yesus,
            distanceKmAddis = 0.0,
            travelTipAmharic = "በአምስት ኪሎ አደባባይ አጠገብ ይገኛል። በታክሲና በአውቶቡስ በቀላሉ መድረስ ይቻላል።"
        ),
        Church(
            id = "ekhc_bethel",
            nameAmharic = "የኢትዮጵያ ቃለ ሕይወት ቤተክርስቲያን (ቀዳማይ ቤቴል)",
            nameEnglish = "Ethiopian Kale Heywet Church (Bethel Head Church)",
            tradition = ReligiousTradition.PROTESTANT,
            denominationOrType = "ቃለ ሕይወት (EKHC)",
            patronSaint = "ቃለ ሕይወት",
            dioceseAmharic = "አዲስ አበባ ማዕከል",
            subCityOrZone = "ልደታ / ሜክሲኮ ክፍለ ከተማ",
            city = "አዲስ አበባ",
            isHistoricOrMonastery = true,
            centuryBuilt = "1927 - 1970ዎቹ ዓ.ም",
            descriptionAmharic = "በኢትዮጵያ እጅግ በርካታ አብያተ ክርስቲያናትና ምእመናን ካሏቸው የወንጌላውያን አብያተ ክርስቲያናት ቀዳሚ የሆነው የቃለ ሕይወት ማዕከላዊ አዳራሽ። በወንጌል ስርጭት፣ በትምህርትና በማኅበራዊ ልማት ትልቅ አሻራ ያረፈበት ማዕከል ነው።",
            latitude = 9.0062,
            longitude = 38.7412,
            addressAmharic = "ሜክሲኮ ሳር ቤት መስመር፣ አዲስ አበባ",
            clergyContacts = listOf(
                ClergyContact("ዋና መጋቢ (Senior Pastor)", "ፓስተር ተስፋዬ ብርሃኑ", "+251 11 551 2233", "አስተዳደር"),
                ClergyContact("የአምልኮ መሪ", "መጋቢ ብሩክ ወርቁ", "+251 91 123 7788", "መዘምራንና አምልኮ")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የእሑድ ጧት አምልኮ", "3:00 - 6:00 (ጧት)", "እሑድ", "የምስጋና፣ የአምልኮና የስብከት ፕሮግራም", ProgramType.LITURGY),
                LiturgyProgram("የአርብ የጸሎትና የፈውስ ፕሮግራም", "11:30 - 1:30 (ማታ)", "አርብ", "የምእመናን የሕብረት ጸሎት", ProgramType.PRAYER_SERVICE)
            ),
            annualFeasts = listOf(
                TabotFeast("ዓመታዊ የቃለ ሕይወት ጠቅላላ ጉባኤ", "ጥር / የካቲት", "Jan / Feb", "ብሔራዊ ጉባኤ", "ከመላው ኢትዮጵያ የተውጣጡ አገልጋዮችና መጋቢዎች የሚገናኙበት")
            ),
            sundaySchoolPrograms = listOf(
                SundaySchoolProgram("የሰንበት ትምህርት ቤት ለሕፃናት", "እሑድ ከጧቱ 3:00", "+251 11 551 2233")
            ),
            localImageDrawable = null,
            distanceKmAddis = 0.0,
            travelTipAmharic = "ከሜክሲኮ አደባባይ ወደ ሳር ቤት በሚወስደው መንገድ ላይ ይገኛል።"
        ),
        Church(
            id = "mulu_wengel_central",
            nameAmharic = "የኢትዮጵያ ሙሉ ወንጌል አማኞች ቤተክርስቲያን (ቄራ ማዕከል)",
            nameEnglish = "Ethiopian Mulu Wengel Believers Church (Kera Central)",
            tradition = ReligiousTradition.PROTESTANT,
            denominationOrType = "ሙሉ ወንጌል (Mulu Wengel)",
            patronSaint = "ሙሉ ወንጌል",
            dioceseAmharic = "አዲስ አበባ",
            subCityOrZone = "ቂርቆስ ክፍለ ከተማ",
            city = "አዲስ አበባ",
            isHistoricOrMonastery = true,
            centuryBuilt = "1959 - 1967 ዓ.ም",
            descriptionAmharic = "በኢትዮጵያ የመጀመሪያው የጴንጤቆስጤ (Pentecostal) ንቅናቄ የመነጨበትና የተመሠረተው ታሪካዊው የሙሉ ወንጌል አማኞች ቤተክርስቲያን። በመንፈሳዊ መነቃቃት፣ በዝማሬና በሕብረት ጸሎት የሚታወቅ ታላቅ ማዕከል ነው።",
            latitude = 9.0028,
            longitude = 38.7565,
            addressAmharic = "ቄራ ጎተራ መስመር፣ ቂርቆስ፣ አዲስ አበባ",
            clergyContacts = listOf(
                ClergyContact("ዋና መጋቢ", "ፓስተር ታደለ ወልደ ዮሐንስ", "+251 11 465 1122", "አስተዳደር"),
                ClergyContact("ጸሐፊ", "ወንድም ሰሎሞን በቀለ", "+251 91 166 3322", "ጽሕፈት ቤት")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የእሑድ ጠዋት አምልኮ", "3:00 - 6:30 (ጧት)", "እሑድ", "ዝማሬ፣ አምልኮና የእግዚአብሔር ቃል", ProgramType.LITURGY),
                LiturgyProgram("የሐሙስ የምልጃ ጸሎት", "11:00 - 1:00 (ማታ)", "ሐሙስ", "የሀገርና የምእመናን የምልጃ ጸሎት", ProgramType.PRAYER_SERVICE)
            ),
            annualFeasts = listOf(
                TabotFeast("ዓመታዊ የጴንጤቆስጤ በዓል", "ሰኔ", "June", "ዓመታዊ ታላቅ ጉባኤ", "የመንፈስ ቅዱስ መውረድ መታሰቢያ")
            ),
            sundaySchoolPrograms = emptyList(),
            localImageDrawable = null,
            distanceKmAddis = 0.0,
            travelTipAmharic = "በቂርቆስ ክፍለ ከተማ ከቄራ አደባባይ ቅርብ ርቀት ላይ ይገኛል።"
        ),
        Church(
            id = "hawassa_mekane_yesus",
            nameAmharic = "ሐዋሳ መካነ ኢየሱስ ቤተክርስቲያን",
            nameEnglish = "Hawassa Mekane Yesus Church",
            tradition = ReligiousTradition.PROTESTANT,
            denominationOrType = "መካነ ኢየሱስ (EECMY)",
            patronSaint = "መካነ ኢየሱስ",
            dioceseAmharic = "ደቡብ ኢትዮጵያ ሲኖዶስ",
            subCityOrZone = "ሐዋሳ ከተማ",
            city = "ሐዋሳ",
            isHistoricOrMonastery = false,
            centuryBuilt = "1970ዎቹ ዓ.ም",
            descriptionAmharic = "በሲዳማ ክልል በሐዋሳ ከተማ እምብርት የሚገኘው ታላቁ የወንጌላዊት ቤተክርስቲያን መካነ ኢየሱስ አዳራሽ። በደቡብ ኢትዮጵያ ሰፊ ምእመናን ያሉት ንቁ የመንፈሳዊና የማኅበረሰብ ልማት ማዕከል ነው።",
            latitude = 7.0581,
            longitude = 38.4815,
            addressAmharic = "ሐዋሳ ከተማ፣ ሲዳማ ክልል",
            clergyContacts = listOf(
                ClergyContact("ዋና መጋቢ", "ፓስተር ዳንኤል ገመቹ", "+251 46 220 1199", "አስተዳደር")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የእሑድ አምልኮ", "3:00 - 6:00 (ጧት)", "እሑድ", "የምስጋናና የቃል አገልግሎት", ProgramType.LITURGY)
            ),
            annualFeasts = listOf(
                TabotFeast("ዓመታዊ የወጣቶች ኮንፈረንስ", "ነሐሴ", "August", "የደቡብ ሲኖዶስ የወጣቶች ጉባኤ", "የወጣቶች መንፈሳዊ ኮንፈረንስ")
            ),
            sundaySchoolPrograms = emptyList(),
            localImageDrawable = null,
            distanceKmAddis = 275.0,
            travelTipAmharic = "በሐዋሳ ከተማ መሃል በዋናው መንገድ ላይ ይገኛል።"
        ),

        // === ISLAMIC MOSQUES / MESJIDS ===
        Church(
            id = "anwar_mosque",
            nameAmharic = "ታላቁ የአንዋር መስጊድ (መርካቶ)",
            nameEnglish = "Grand Anwar Mosque (Mercato, Addis Ababa)",
            tradition = ReligiousTradition.ISLAM,
            denominationOrType = "ታላቅ ጃሚዕ መስጊድ (ሱኒ)",
            patronSaint = "አል-አንዋር",
            dioceseAmharic = "የአዲስ አበባ እስልምና ጉዳዮች ከፍተኛ ምክር ቤት (መጅሊስ)",
            subCityOrZone = "አዲስ ከተማ ክፍለ ከተማ",
            city = "አዲስ አበባ",
            isHistoricOrMonastery = true,
            isCathedral = true,
            centuryBuilt = "1922 ዓ.ም (1930 እ.ኤ.አ)",
            descriptionAmharic = "በኢትዮጵያና በአዲስ አበባ ትልቁና ታሪካዊው ማዕከላዊ መስጊድ። በመርካቶ እምብርት የሚገኘው ታላቁ አንዋር መስጊድ፤ በመቶ ሺዎች የሚቆጠሩ የእስልምና ተከታዮች በየዕለቱና በጁምዓ ሰላት የሚሰባሰቡበት፣ ውብ አረንጓዴ ጉልላትና ረጅም ሚናራ ያለው ብሔራዊ የእስልምና ቅርስ ነው።",
            latitude = 9.0305,
            longitude = 38.7390,
            addressAmharic = "መርካቶ፣ አዲስ ከተማ ክፍለ ከተማ፣ አዲስ አበባ",
            clergyContacts = listOf(
                ClergyContact("ዋና ኢማም (Chief Imam)", "ሸይኽ ሙሐመድ ዘይን ዘህረዲን", "+251 11 275 4400", "የሰላትና የኹጥባ መሪ"),
                ClergyContact("የመስጊዱ አስተዳዳሪ ኮሚቴ ሰብሳቢ", "ሐጂ ኑሩ ሑሴን", "+251 91 120 5566", "አስተዳደር"),
                ClergyContact("የመድረሳና ቂርዓት ተጠሪ", "ኡስታዝ አብዱራሕማን ሸሪፍ", "+251 91 180 7799", "ትምህርት")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የጁምዓ ሰላትና ኹጥባ (Friday Jummah Prayer)", "6:30 - 7:45 (ቀን)", "አርብ (Jummah)", "ታላቁ የጁምዓ ሰላትና ሳምንታዊው የኢማሙ ኹጥባ", ProgramType.JUMMAH),
                LiturgyProgram("የአምስቱ ወቅት ሰላቶች (5 Daily Prayers)", "በየዕለቱ በወቅቱ", "በየቀኑ (Daily)", "ፈጅር (Subhi)፣ ዙህር (Dhuhr)፣ ዓስር (Asr)፣ መግሪብ (Maghrib)፣ ዒሻእ (Isha)", ProgramType.PRAYER_SERVICE),
                LiturgyProgram("የሐዲሥና የተፍሲር ትምህርት", "ከመግሪብ እስከ ዒሻእ", "ቅዳሜና እሑድ", "የቅዱስ ቁርኣንና የነብዩ ሙሐመድ (ሰ.ዐ.ወ) ሐዲሥ ትምህርት", ProgramType.SUNDAY_SCHOOL)
            ),
            annualFeasts = listOf(
                TabotFeast("ዒድ አል-ፈጥር (Eid al-Fitr)", "የሸዋል ወር መባቻ", "ረመዳን መጨረሻ", "የረመዳን ጾም ፍቺ ታላቅ በዓል", "በሚሊዮኖች የሚቆጠሩ ሙስሊሞች በመስጊዱና በመስቀል አደባባይ ታላቅ ሰላት የሚያሰግዱበት"),
                TabotFeast("ዒድ አል-አድሃ (Arafa / Eid al-Adha)", "ዙልሒጃ 10", "የሐጅ ወቅት", "የአረፋ ታላቅ በዓል", "የመስዋዕትና የታላቁ የአረፋ በዓል ሰላት"),
                TabotFeast("መውሊድ አን-ነበዊ (Mawlid)", "ረቢዑል አወል 12", "የነብዩ ልደት", "የነብዩ ሙሐመድ (ሰ.ዐ.ወ) የልደት መታሰቢያ", "የመንዙማና የምስጋና ታላቅ ፕሮግራም")
            ),
            sundaySchoolPrograms = listOf(
                SundaySchoolProgram("የአንዋር መስጊድ መድረሳ (Madrasa)", "ዘወትር ከሰኞ እስከ አርብ ከቀኑ 10:00", "+251 11 275 4400"),
                SundaySchoolProgram("የሕፃናት የቁርኣን ሂፍዝ (Quran Memorization)", "ቅዳሜና እሑድ ጧት", "+251 91 180 7799")
            ),
            localImageDrawable = R.drawable.img_anwar_mosque,
            distanceKmAddis = 0.0,
            travelTipAmharic = "በመርካቶ እምብርት ይገኛል። አርብ በጁምዓ ወቅት ከፍተኛ የሰዎችና የመኪና መጨናነቅ ስላለ አስቀድሞ በእግር መድረስ ይመረጣል።"
        ),
        Church(
            id = "nejashi_mosque",
            nameAmharic = "ታሪካዊው አል-ነጃሺ መስጊድ (ነጋሽ)",
            nameEnglish = "Historic Al-Nejashi Mosque (Negash, Tigray)",
            tradition = ReligiousTradition.ISLAM,
            denominationOrType = "ታሪካዊ የመጀመሪያው የአፍሪካ መስጊድ",
            patronSaint = "አስ-ሐማ ነጃሺ",
            dioceseAmharic = "የትግራይ ክልል እስልምና ጉዳዮች",
            subCityOrZone = "ክሊተ አውላዕሎ / ውቅሮ አጠገብ",
            city = "ነጋሽ",
            isHistoricOrMonastery = true,
            isCathedral = true,
            centuryBuilt = "7ኛው መቶ ክፍለ ዘመን (615 እ.ኤ.አ / 1ኛው ክፍለ ዘመን ሂጅሪያ)",
            descriptionAmharic = "በአፍሪካ ምድር የመጀመሪያው፣ በዓለምም እጅግ ጥንታዊ ከሚባሉት መስጊዶች አንዱ የሆነው አል-ነጃሺ። ነብዩ ሙሐመድ (ሰ.ዐ.ወ) የመጀመሪያዎቹን ሙስሊሞች (ሰሓቦች) ወደ ኢትዮጵያ በላኩበት ወቅት በፍትሐዊው የአክሱም ንጉሥ ነጃሺ (አስ-ሐማ) ጥበቃ ተደርጎላቸው የተመሠረተ የዓለም አቀፍ እስልምና ቅርስ ነው። የ15ቱ ሰሓቦች መቃብር ይገኝበታል።",
            latitude = 13.7925,
            longitude = 39.5983,
            addressAmharic = "ነጋሽ መንደር፣ ውቅሮ አቅራቢያ፣ ትግራይ ክልል",
            clergyContacts = listOf(
                ClergyContact("የመስጊዱ ኢማም", "ሸይኽ አደም ዐብደላህ", "+251 91 475 2211", "ኢማም"),
                ClergyContact("የቅርስና ዚያራ አስተባባሪ", "ኡስታዝ ሐሰን ዑመር", "+251 91 488 3344", "ዚያራና መስተንግዶ")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የጁምዓ ሰላት", "6:30 - 7:30 (ቀን)", "አርብ", "የሳምንቱ የጁምዓ ኹጥባና ሰላት", ProgramType.JUMMAH),
                LiturgyProgram("የአምስቱ ወቅት ሰላቶች", "በየቀኑ", "በየቀኑ", "ፈጅር፣ ዙህር፣ ዓስር፣ መግሪብ፣ ዒሻእ", ProgramType.PRAYER_SERVICE)
            ),
            annualFeasts = listOf(
                TabotFeast("ዓመታዊው የአል-ነጃሺ ዚያራ (Annual Ziyarah)", "ሙሐረም 10 (አሹራ)", "Muharram", "ዓመታዊ ታላቅ የዚያራ ጉዞ", "ከመላው ዓለምና ከኢትዮጵያ የሚመጡ ምእመናን የሰሓቦችን ታሪክ የሚያስቡበት")
            ),
            sundaySchoolPrograms = listOf(
                SundaySchoolProgram("የነጋሽ ጥንታዊ መድረሳ", "በየቀኑ", "+251 91 475 2211")
            ),
            localImageDrawable = null,
            distanceKmAddis = 810.0,
            travelTipAmharic = "ከመቐለ በስተሰሜን 60 ኪሎ ሜትር፣ ከውቅሮ በ10 ኪሎ ሜትር ርቀት ላይ ይገኛል። ከመቐለ በመኪና በቀላሉ መድረስ ይቻላል።"
        ),
        Church(
            id = "harar_jamia_mosque",
            nameAmharic = "ታላቁ የሐረር ጁምዓ መስጊድ (ጃሚዕ)",
            nameEnglish = "Grand Jamia Mosque of Harar Jugol",
            tradition = ReligiousTradition.ISLAM,
            denominationOrType = "ታሪካዊ የሐረር ጁጎል መስጊድ",
            patronSaint = "አሚር ኑር / ሸይኽ አባድር",
            dioceseAmharic = "የሐረሪ ክልል እስልምና ጉዳዮች",
            subCityOrZone = "ሐረር ጁጎል (የግንብ ከተማ)",
            city = "ሐረር",
            isHistoricOrMonastery = true,
            isCathedral = true,
            centuryBuilt = "10ኛው - 16ኛው መቶ ክፍለ ዘመን",
            descriptionAmharic = "በዓለም በዩኔስኮ የተመዘገበችው የሐረር ጁጎል አራተኛዋ የእስልምና ቅድስት ከተማ ናት። ከ82ቱ የሐረር መስጊዶች መካከል ታላቁና ማዕከላዊው የጁምዓ ጃሚዕ መስጊድ በውብ ነጭ ግንቡና ባለ ሁለት ሚናራው ጥንታዊ የእስልምና ሥልጣኔ ማሳያ ነው።",
            latitude = 9.3128,
            longitude = 42.1332,
            addressAmharic = "ሐረር ጁጎል ማዕከል፣ ሐረሪ ክልል",
            clergyContacts = listOf(
                ClergyContact("የጃሚዕ መስጊድ ኢማም", "ሸይኽ አብዱልከሪም ሐጂ ዩሱፍ", "+251 25 666 1122", "ዋና ኢማም")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የጁምዓ ታላቅ ሰላት", "6:30 - 7:30 (ቀን)", "አርብ", "የሐረር ጁጎል ምእመናን ታላቅ ሰላት", ProgramType.JUMMAH)
            ),
            annualFeasts = listOf(
                TabotFeast("የአሹራና የዒድ በዓላት በሐረር", "ዙልሒጃ / ሙሐረም", "የተለያዩ ወቅቶች", "ታላቅ የሐረር ባህላዊና ሃይማኖታዊ በዓል", "የሐረሪ ሙስሊሞች በደማቅ ባህል የሚያከብሩት")
            ),
            sundaySchoolPrograms = emptyList(),
            localImageDrawable = null,
            distanceKmAddis = 525.0,
            travelTipAmharic = "በአውሮፕላን ድሬዳዋ ደርሶ በመኪና በ1 ሰዓት ጉዞ ወደ ሐረር መግባት ይቻላል።"
        ),
        Church(
            id = "nur_mosque",
            nameAmharic = "ኑር መስጊድ (ፒያሳ)",
            nameEnglish = "Masjid An-Nur (Piassa, Addis Ababa)",
            tradition = ReligiousTradition.ISLAM,
            denominationOrType = "አህለሱና መስጊድ",
            patronSaint = "አን-ኑር",
            dioceseAmharic = "አዲስ አበባ",
            subCityOrZone = "አራዳ ክፍለ ከተማ",
            city = "አዲስ አበባ",
            isHistoricOrMonastery = false,
            centuryBuilt = "1960ዎቹ ዓ.ም",
            descriptionAmharic = "በአዲስ አበባ ፒያሳና ቸርችል ጎዳና መገናኛ ላይ የሚገኘው ታዋቂው ኑር መስጊድ። ለከተማው ማዕከል ቅርብ በመሆኑ በየቀኑ በሺዎች የሚቆጠሩ ሠራተኞችና ነጋዴዎች ሰላታቸውን የሚያደርሱበት ማዕከል ነው።",
            latitude = 9.0255,
            longitude = 38.7525,
            addressAmharic = "ቸርችል ጎዳና፣ ፒያሳ፣ አዲስ አበባ",
            clergyContacts = listOf(
                ClergyContact("ኢማም", "ሸይኽ ሙሐመድ ሳኒ", "+251 11 156 7788", "ኢማም")
            ),
            weeklyPrograms = listOf(
                LiturgyProgram("የጁምዓ ሰላት", "6:30 - 7:30 (ቀን)", "አርብ", "የሳምንቱ የጁምዓ ጸሎት", ProgramType.JUMMAH)
            ),
            annualFeasts = emptyList(),
            sundaySchoolPrograms = emptyList(),
            localImageDrawable = null,
            distanceKmAddis = 0.0,
            travelTipAmharic = "በቸርችል ጎዳና ከቴዎድሮስ አደባባይ ጥቂት ሜትሮች ዝቅ ብሎ ይገኛል።"
        )
    )

    private val mutablePlaces = allWorshipPlaces.toMutableList()
    private val _placesFlow = MutableStateFlow<List<Church>>(mutablePlaces)
    val churches: Flow<List<Church>> = _placesFlow.asStateFlow()

    fun getAllChurches(): List<Church> = mutablePlaces.toList()

    fun getChurchById(id: String): Church? = mutablePlaces.firstOrNull { it.id == id }

    fun addChurch(church: Church) {
        mutablePlaces.add(0, church)
        _placesFlow.value = mutablePlaces.toList()
    }

    fun deleteChurch(id: String) {
        mutablePlaces.removeAll { it.id == id }
        _placesFlow.value = mutablePlaces.toList()
    }

    fun getCities(): List<String> = listOf(
        "ሁሉንም",
        "አዲስ አበባ",
        "ላሊበላ",
        "አክሱም",
        "ነጋሽ",
        "ጎንደር",
        "ባሕር ዳር",
        "ሐረር",
        "ሐዋሳ",
        "ደብረ ሊባኖስ"
    )

    fun searchAndFilter(
        query: String,
        selectedTradition: ReligiousTradition? = null,
        selectedCity: String = "ሁሉንም",
        onlyHistoric: Boolean = false,
        onlyCathedrals: Boolean = false
    ): List<Church> {
        return mutablePlaces.filter { place ->
            val matchesQuery = query.isBlank() ||
                    place.nameAmharic.contains(query, ignoreCase = true) ||
                    place.nameEnglish.contains(query, ignoreCase = true) ||
                    place.city.contains(query, ignoreCase = true) ||
                    place.subCityOrZone.contains(query, ignoreCase = true) ||
                    place.patronSaint.contains(query, ignoreCase = true) ||
                    place.denominationOrType.contains(query, ignoreCase = true) ||
                    place.descriptionAmharic.contains(query, ignoreCase = true)

            val matchesTradition = selectedTradition == null || place.tradition == selectedTradition
            val matchesCity = selectedCity == "ሁሉንም" || place.city.contains(selectedCity) || place.dioceseAmharic.contains(selectedCity)
            val matchesHistoric = !onlyHistoric || place.isHistoricOrMonastery
            val matchesCathedral = !onlyCathedrals || place.isCathedral

            matchesQuery && matchesTradition && matchesCity && matchesHistoric && matchesCathedral
        }
    }
}
