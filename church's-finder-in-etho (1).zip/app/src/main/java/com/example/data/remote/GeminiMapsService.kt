package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class GroundingPlace(
    val title: String,
    val uri: String?,
    val address: String?
)

data class MapsAiResponse(
    val text: String,
    val placesFound: List<GroundingPlace> = emptyList(),
    val isSuccess: Boolean = true,
    val errorMessage: String? = null
)

class GeminiMapsService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun queryMapsGrounding(
        prompt: String,
        churchContext: String? = null
    ): MapsAiResponse = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext MapsAiResponse(
                text = "የGoogle Maps መረጃን ለማግኘት እባክዎ በAI Studio Secrets ፓነል ውስጥ GEMINI_API_KEY ያስገቡ።\n(Please configure GEMINI_API_KEY in the Secrets panel to enable live Google Maps grounding).",
                isSuccess = false,
                errorMessage = "API key not configured"
            )
        }

        try {
            val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

            val fullPrompt = if (!churchContext.isNullOrBlank()) {
                "Religious Site / Church / Mosque Context: $churchContext\n\nUser Question: $prompt\n\nPlease answer accurately using real-time Google Maps information regarding routes, terrain, travel times, nearby landmarks in Ethiopia, and local guidance in respectful Amharic (and key points in English)."
            } else {
                "User Question regarding Ethiopian Churches, Protestant Centers, or Mosques / Navigation in Ethiopia: $prompt\n\nPlease use Google Maps data to find accurate locations, distances, road conditions, and practical travel tips in Ethiopia. Respond in Amharic (አማርኛ)."
            }

            val requestBodyJson = JSONObject().apply {
                val contentsArray = JSONArray()
                val userContent = JSONObject().apply {
                    put("role", "user")
                    val partsArray = JSONArray()
                    partsArray.put(JSONObject().apply { put("text", fullPrompt) })
                    put("parts", partsArray)
                }
                contentsArray.put(userContent)
                put("contents", contentsArray)

                // Tools: Google Maps tool grounding
                val toolsArray = JSONArray()
                val mapsTool = JSONObject()
                mapsTool.put("googleMaps", JSONObject())
                toolsArray.put(mapsTool)
                put("tools", toolsArray)

                // System Instruction
                val systemInstruction = JSONObject().apply {
                    val partsArray = JSONArray()
                    partsArray.put(JSONObject().apply {
                        put("text", "You are an expert Ethiopian religious geography and road navigation guide covering Ethiopian Orthodox Tewahedo Churches, Protestant/Evangelical Churches, and Islamic Mosques across Ethiopia. You use Google Maps grounding to provide verified GPS locations, road directions across Ethiopian highways, mountain topography, local transport tips, and travel safety. Respond warmly and respectfully in Amharic (አማርኛ).")
                    })
                    put("parts", partsArray)
                }
                put("systemInstruction", systemInstruction)
            }

            val request = Request.Builder()
                .url(endpoint)
                .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e("GeminiMapsService", "API error code ${response.code}: $responseString")
                // If googleMaps tool is restricted or model format requires fallback, try standard search or informative response
                return@withContext fallbackQuery(prompt, churchContext, apiKey, response.code, responseString)
            }

            val responseJson = JSONObject(responseString)
            val candidates = responseJson.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext MapsAiResponse(
                    text = "ምንም መረጃ አልተገኘም። እባክዎ ጥያቄዎን በድጋሚ ይሞክሩ።",
                    isSuccess = false
                )
            }

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")

            val textBuilder = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    if (part.has("text")) {
                        textBuilder.append(part.getString("text"))
                    }
                }
            }

            val places = mutableListOf<GroundingPlace>()
            val groundingMetadata = firstCandidate.optJSONObject("groundingMetadata")
            if (groundingMetadata != null) {
                val chunks = groundingMetadata.optJSONArray("groundingChunks")
                if (chunks != null) {
                    for (i in 0 until chunks.length()) {
                        val chunk = chunks.getJSONObject(i)
                        val web = chunk.optJSONObject("web")
                        val maps = chunk.optJSONObject("maps")
                        val title = maps?.optString("title") ?: web?.optString("title") ?: ""
                        val uri = maps?.optString("uri") ?: web?.optString("uri")
                        val address = maps?.optString("address")
                        if (title.isNotBlank()) {
                            places.add(GroundingPlace(title, uri, address))
                        }
                    }
                }
            }

            MapsAiResponse(
                text = textBuilder.toString().ifBlank { "መረጃው ተጠናቅቋል።" },
                placesFound = places,
                isSuccess = true
            )
        } catch (e: Exception) {
            Log.e("GeminiMapsService", "Exception in Maps Grounding", e)
            MapsAiResponse(
                text = "የካርታ መረጃን በማምጣት ላይ ችግር ተፈጥሯል: ${e.localizedMessage ?: "ያልታወቀ ስህተት"}",
                isSuccess = false,
                errorMessage = e.message
            )
        }
    }

    private suspend fun fallbackQuery(
        prompt: String,
        churchContext: String?,
        apiKey: String,
        errorCode: Int,
        errorBody: String
    ): MapsAiResponse = withContext(Dispatchers.IO) {
        try {
            // Attempt standard generateContent if googleMaps tool parameter needs search grounding
            val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
            val queryText = if (!churchContext.isNullOrBlank()) {
                "Location: $churchContext\nUser question: $prompt\nProvide accurate Ethiopian road, distance, and location guidance for this church."
            } else {
                "Ethiopian Church Navigation: $prompt\nProvide accurate road travel advice in Amharic."
            }

            val fallbackJson = JSONObject().apply {
                val contentsArray = JSONArray()
                val userContent = JSONObject().apply {
                    put("role", "user")
                    val partsArray = JSONArray()
                    partsArray.put(JSONObject().apply { put("text", queryText) })
                    put("parts", partsArray)
                }
                contentsArray.put(userContent)
                put("contents", contentsArray)

                val toolsArray = JSONArray()
                val searchTool = JSONObject().apply {
                    put("googleSearch", JSONObject())
                }
                toolsArray.put(searchTool)
                put("tools", toolsArray)
            }

            val request = Request.Builder()
                .url(endpoint)
                .post(fallbackJson.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val responseJson = JSONObject(responseString)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                    val textBuilder = StringBuilder()
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            textBuilder.append(parts.getJSONObject(i).optString("text", ""))
                        }
                    }
                    return@withContext MapsAiResponse(
                        text = textBuilder.toString(),
                        isSuccess = true
                    )
                }
            }
        } catch (_: Exception) {}

        MapsAiResponse(
            text = "የካርታ መረጃ ጥያቄ አልተሳካም (Error $errorCode). እባክዎ የቀጥታ Google Maps አቅጣጫ ቁልፍን ይጠቀሙ።",
            isSuccess = false,
            errorMessage = errorBody
        )
    }
}
