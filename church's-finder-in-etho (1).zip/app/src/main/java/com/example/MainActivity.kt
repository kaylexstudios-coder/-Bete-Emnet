package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.AdminAddChurchScreen
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AdminLoginScreen
import com.example.ui.screens.ChurchDetailScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiturgicalCalendarScreen
import com.example.ui.screens.MapsAiScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.ChurchViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ChurchViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    BeteEmnetApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun BeteEmnetApp(viewModel: ChurchViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Crossfade(
        targetState = uiState.currentScreen,
        label = "screen_transition"
    ) { screen ->
        when (screen) {
            AppScreen.HOME -> {
                HomeScreen(
                    uiState = uiState,
                    cities = viewModel.cities,
                    onSearchChange = viewModel::onSearchQueryChanged,
                    onTraditionSelect = viewModel::onTraditionSelected,
                    onCitySelect = viewModel::onCitySelected,
                    onToggleHistoric = viewModel::toggleHistoricFilter,
                    onToggleCathedral = viewModel::toggleCathedralFilter,
                    onResetFilters = viewModel::resetFilters,
                    onChurchClick = viewModel::selectChurch,
                    onFavoriteToggle = viewModel::toggleFavorite,
                    onOpenMapsAi = { viewModel.navigateTo(AppScreen.MAPS_AI) },
                    onOpenFavorites = { viewModel.navigateTo(AppScreen.FAVORITES) },
                    onOpenCalendar = { viewModel.navigateTo(AppScreen.CALENDAR) },
                    onOpenAdmin = {
                        viewModel.navigateTo(
                            if (uiState.isAdminLoggedIn) AppScreen.ADMIN_DASHBOARD else AppScreen.ADMIN_LOGIN
                        )
                    }
                )
            }
            AppScreen.DETAIL -> {
                uiState.selectedChurch?.let { church ->
                    ChurchDetailScreen(
                        church = church,
                        isFavorite = uiState.favoriteIds.contains(church.id),
                        onBackClick = viewModel::navigateBack,
                        onFavoriteToggle = { viewModel.toggleFavorite(church.id) },
                        onAskAiMapsClick = { viewModel.navigateTo(AppScreen.MAPS_AI) }
                    )
                } ?: run {
                    viewModel.navigateBack()
                }
            }
            AppScreen.MAPS_AI -> {
                MapsAiScreen(
                    currentResponse = uiState.currentMapsAiResponse,
                    isLoading = uiState.mapsAiLoading,
                    conversationHistory = uiState.aiConversationHistory,
                    selectedChurch = uiState.selectedChurch,
                    onBackClick = viewModel::navigateBack,
                    onAskQuery = { query, church ->
                        viewModel.askMapsAdvisor(query, church)
                    }
                )
            }
            AppScreen.FAVORITES -> {
                val favoriteChurches = uiState.churches.filter { uiState.favoriteIds.contains(it.id) }
                FavoritesScreen(
                    favoriteChurches = favoriteChurches,
                    favoriteIds = uiState.favoriteIds,
                    onChurchClick = viewModel::selectChurch,
                    onFavoriteToggle = viewModel::toggleFavorite,
                    onBackClick = viewModel::navigateBack
                )
            }
            AppScreen.CALENDAR -> {
                LiturgicalCalendarScreen(
                    onBackClick = viewModel::navigateBack
                )
            }
            AppScreen.ADMIN_LOGIN -> {
                AdminLoginScreen(
                    emailInput = uiState.adminEmailInput,
                    passwordInput = uiState.adminPasswordInput,
                    loginError = uiState.adminLoginError,
                    onEmailChange = viewModel::onAdminEmailChanged,
                    onPasswordChange = viewModel::onAdminPasswordChanged,
                    onLoginClick = { viewModel.loginAdmin() },
                    onBackClick = viewModel::navigateBack
                )
            }
            AppScreen.ADMIN_DASHBOARD -> {
                AdminDashboardScreen(
                    churches = uiState.churches,
                    successMessage = uiState.adminSuccessMessage,
                    onAddPlaceClick = { viewModel.navigateTo(AppScreen.ADMIN_ADD_CHURCH) },
                    onViewPlaceClick = viewModel::selectChurch,
                    onDeletePlaceClick = viewModel::deletePlaceOfWorship,
                    onClearSuccessMessage = viewModel::clearAdminSuccessMessage,
                    onLogoutClick = viewModel::logoutAdmin,
                    onBackClick = viewModel::navigateBack
                )
            }
            AppScreen.ADMIN_ADD_CHURCH -> {
                AdminAddChurchScreen(
                    onSavePlace = viewModel::addNewPlaceOfWorship,
                    onBackClick = viewModel::navigateBack
                )
            }
        }
    }
}
