package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.data.model.Church

object DirectionsLauncher {

    fun launchGoogleMapsDirections(context: Context, church: Church) {
        val lat = church.latitude
        val lng = church.longitude
        val label = Uri.encode(church.nameAmharic)

        // Try Google Maps Navigation URI first
        val gmmIntentUri = Uri.parse("google.navigation:q=$lat,$lng&mode=d")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
            setPackage("com.google.android.apps.maps")
        }

        try {
            context.startActivity(mapIntent)
        } catch (_: Exception) {
            // Fallback to universal browser / map web intent
            val webUri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&destination_name=$label")
            val webIntent = Intent(Intent.ACTION_VIEW, webUri)
            try {
                context.startActivity(webIntent)
            } catch (e: Exception) {
                Toast.makeText(context, "ካርታ መክፈት አልተቻለም: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun openLocationOnMap(context: Context, church: Church) {
        val lat = church.latitude
        val lng = church.longitude
        val label = Uri.encode(church.nameAmharic)
        val geoUri = Uri.parse("geo:$lat,$lng?q=$lat,$lng($label)")
        val intent = Intent(Intent.ACTION_VIEW, geoUri)
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng")
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
            } catch (e: Exception) {
                Toast.makeText(context, "ካርታ መክፈት አልተቻለም", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun dialPhoneNumber(context: Context, phoneNumber: String) {
        try {
            val cleanNumber = phoneNumber.replace(" ", "")
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanNumber"))
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "ስልክ መደወል አልተቻለም: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareChurchInfo(context: Context, church: Church) {
        val feasts = church.annualFeasts.joinToString(", ") { "${it.saintNameAmharic} (${it.ethiopianDate})" }
        val shareText = """
            ⛪ ${church.nameAmharic} (${church.nameEnglish})
            📍 ሀገረ ስብከት: ${church.dioceseAmharic}፣ ${church.city}
            🏛 ዘመን: ${church.centuryBuilt}
            📅 ዓመታዊ ንግሥ: $feasts
            📍 Google Maps መገኛ: https://www.google.com/maps/search/?api=1&query=${church.latitude},${church.longitude}
            
            በተዋሕዶ አብያተ ክርስቲያናት መተግበሪያ የተጋራ
        """.trimIndent()

        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, shareText)
            type = "text/plain"
        }
        context.startActivity(Intent.createChooser(sendIntent, "ስለ ${church.nameAmharic} አጋራ"))
    }
}
