package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Church
import com.example.data.model.ClergyContact
import com.example.data.model.LiturgyProgram
import com.example.data.model.ProgramType
import com.example.data.model.ReligiousTradition
import com.example.data.model.TabotFeast
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAddChurchScreen(
    onSavePlace: (Church) -> Unit,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBackClick() }

    // Tradition selection
    var tradition by remember { mutableStateOf(ReligiousTradition.ORTHODOX) }

    // Core Infos
    var nameAmharic by remember { mutableStateOf("") }
    var nameEnglish by remember { mutableStateOf("") }
    var denominationOrType by remember { mutableStateOf("ኦርቶዶክስ ተዋሕዶ") }
    var city by remember { mutableStateOf("አዲስ አበባ") }
    var subCityOrZone by remember { mutableStateOf("ቂርቆስ ክፍለ ከተማ") }
    var diocese by remember { mutableStateOf("አዲስ አበባ") }
    var centuryBuilt by remember { mutableStateOf("1980ዎቹ ዓ.ም") }
    var descriptionAmharic by remember { mutableStateOf("") }
    var addressAmharic by remember { mutableStateOf("") }
    var latitudeText by remember { mutableStateOf("9.0200") }
    var longitudeText by remember { mutableStateOf("38.7500") }
    var travelTip by remember { mutableStateOf("") }
    var isHistoric by remember { mutableStateOf(false) }

    // Program / Schedule
    var programTitle by remember { mutableStateOf("የሰንበት ጧት ቅዳሴ") }
    var programTime by remember { mutableStateOf("12:00 - 3:00 ጧት") }
    var programDay by remember { mutableStateOf("እሑድ") }
    var programDesc by remember { mutableStateOf("የምእመናን ጸሎትና ቃለ እግዚአብሔር") }

    // Annual Feast
    var feastName by remember { mutableStateOf("ዓመታዊ ንግሥ") }
    var feastDate by remember { mutableStateOf("ጥር 21") }

    // Leader / Clergy
    var contactTitle by remember { mutableStateOf("አስተዳዳሪ") }
    var contactName by remember { mutableStateOf("አባ / ፓስተር / ሸይኽ") }
    var contactPhone by remember { mutableStateOf("+251 91 100 0000") }

    // Image preset options
    val imagePresets = listOf(
        Pair("ቤተ እምነት Logo", R.drawable.ic_bete_emnet_logo),
        Pair("ላሊበላ ቤተክርስቲያን", R.drawable.img_lalibela),
        Pair("አክሱም ጽዮን ማርያም", R.drawable.img_axum),
        Pair("ሥላሴ ካቴድራል", R.drawable.img_addis_selassie),
        Pair("መካነ ኢየሱስ ቤተክርስቲያን", R.drawable.img_mekane_yesus),
        Pair("አንዋር መስጊድ", R.drawable.img_anwar_mosque)
    )
    var selectedImageRes by remember { mutableStateOf<Int?>(R.drawable.ic_bete_emnet_logo) }

    var formError by remember { mutableStateOf<String?>(null) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "አዲስ መረጃ መዝግብ (Add Place)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("admin_add_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ተመለስ"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header Info Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "በዚህ ቅጽ አዳዲስ አብያተ ክርስቲያናት ወይም መስጊዶችን፣ መርሐ ግብራትንና ፎቶዎችን ማካተት ይችላሉ።",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // Quick Pre-Fill Templates
            Text(
                text = "ፈጣን አብነቶች (Quick Template Pre-fills):",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        tradition = ReligiousTradition.ORTHODOX
                        nameAmharic = "ደብረ ምጥማቅ ቅድስት ማርያም"
                        nameEnglish = "Debre Mitmaq Saint Mary Church"
                        denominationOrType = "ኦርቶዶክስ ተዋሕዶ"
                        city = "አዲስ አበባ"
                        subCityOrZone = "ኮተቤ / የካ"
                        diocese = "አዲስ አበባ"
                        centuryBuilt = "1965 ዓ.ም"
                        descriptionAmharic = "በአዲስ አበባ በየካ ተራሮች ስር የምትገኝ ታሪካዊትና በደማቅ የእመቤታችን ጽዮን ማርያም በዓል የምትታወቅ ቤተክርስቲያን።"
                        addressAmharic = "የካ ክፍለ ከተማ፣ ኮተቤ፣ አዲስ አበባ"
                        latitudeText = "9.0350"
                        longitudeText = "38.8150"
                        programTitle = "የሰንበት ቅዳሴ"
                        programTime = "12:00 - 3:00 ጧት"
                        programDay = "እሑድ"
                        feastName = "ማርያም (ኅዳር 21 እና ግንቦት 1)"
                        contactTitle = "የደብሩ አስተዳዳሪ"
                        contactName = "መልአከ ሰላም አባ ገብረ ሥላሴ"
                        selectedImageRes = R.drawable.img_addis_selassie
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("ኦርቶዶክስ", style = MaterialTheme.typography.labelSmall)
                }

                OutlinedButton(
                    onClick = {
                        tradition = ReligiousTradition.PROTESTANT
                        nameAmharic = "የኢትዮጵያ ቃለ ሕይወት ቤተክርስቲያን (ገርጂ)"
                        nameEnglish = "Ethiopian Kale Heywet Church (Gerji)"
                        denominationOrType = "ቃለ ሕይወት (EKHC)"
                        city = "አዲስ አበባ"
                        subCityOrZone = "ቦሌ ክፍለ ከተማ (ገርጂ)"
                        diocese = "አዲስ አበባ"
                        centuryBuilt = "1985 ዓ.ም"
                        descriptionAmharic = "በገርጂ አካባቢ ንቁ የወጣቶችና የቤተሰብ ህብረት ያላት ታላቅ የወንጌላዊት ቃለ ሕይወት አጥቢያ ቤተክርስቲያን።"
                        addressAmharic = "ገርጂ መብራት ኃይል አጠገብ፣ ቦሌ፣ አዲስ አበባ"
                        latitudeText = "8.9880"
                        longitudeText = "38.7990"
                        programTitle = "የእሑድ አምልኮ"
                        programTime = "3:30 - 6:30 ጧት"
                        programDay = "እሑድ"
                        feastName = "ዓመታዊ የትንሣኤ ኮንፈረንስ"
                        contactTitle = "ዋና መጋቢ"
                        contactName = "ፓስተር ብሥራት ተክሌ"
                        selectedImageRes = R.drawable.img_mekane_yesus
                    },
                    modifier = Modifier.weight(1.1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("ፕሮቴስታንት", style = MaterialTheme.typography.labelSmall)
                }

                OutlinedButton(
                    onClick = {
                        tradition = ReligiousTradition.ISLAM
                        nameAmharic = "ቢላል መስጊድ (ሳር ቤት)"
                        nameEnglish = "Bilal Mosque (Sarbet, Addis Ababa)"
                        denominationOrType = "ሱኒ መስጊድ"
                        city = "አዲስ አበባ"
                        subCityOrZone = "ቂርቆስ ክፍለ ከተማ"
                        diocese = "አዲስ አበባ መጅሊስ"
                        centuryBuilt = "1978 ዓ.ም"
                        descriptionAmharic = "በሳር ቤት አካባቢ የሚገኝና በየዕለቱና በጁምዓ ወቅት ሰፊ ሙስሊሞች ሶላታቸውን የሚያደርሱበት መስጊድ።"
                        addressAmharic = "ሳር ቤት ካናዳ ኤምባሲ ፊት ለፊት፣ አዲስ አበባ"
                        latitudeText = "9.0015"
                        longitudeText = "38.7360"
                        programTitle = "የጁምዓ ሰላትና ኹጥባ"
                        programTime = "6:30 - 7:30 ቀን"
                        programDay = "አርብ"
                        feastName = "ዒድ አል-ፈጥርና ዒድ አል-አድሃ"
                        contactTitle = "ኢማም"
                        contactName = "ሸይኽ ዑስማን ሐቢብ"
                        selectedImageRes = R.drawable.img_anwar_mosque
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("መስጊድ", style = MaterialTheme.typography.labelSmall)
                }
            }

            // Tradition Selector Chips
            Text(
                text = "የእምነት ዘርፍ ምረጥ (Religious Tradition):",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = tradition == ReligiousTradition.ORTHODOX,
                    onClick = {
                        tradition = ReligiousTradition.ORTHODOX
                        denominationOrType = "ኦርቶዶክስ ተዋሕዶ"
                    },
                    label = { Text("ኦርቶዶክስ ተዋሕዶ") },
                    shape = RoundedCornerShape(12.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.weight(1f)
                )

                FilterChip(
                    selected = tradition == ReligiousTradition.PROTESTANT,
                    onClick = {
                        tradition = ReligiousTradition.PROTESTANT
                        denominationOrType = "ፕሮቴስታንት / ወንጌላዊ"
                    },
                    label = { Text("ፕሮቴስታንት") },
                    shape = RoundedCornerShape(12.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF1E5B94),
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.weight(1f)
                )

                FilterChip(
                    selected = tradition == ReligiousTradition.ISLAM,
                    onClick = {
                        tradition = ReligiousTradition.ISLAM
                        denominationOrType = "እስልምና መስጊድ"
                    },
                    label = { Text("መስጊድ") },
                    shape = RoundedCornerShape(12.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF1E7E34),
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            // Section 1: Names & Basic Info
            Text(
                text = "1. አጠቃላይ መረጃና ስያሜ (General Info)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = nameAmharic,
                onValueChange = { nameAmharic = it },
                label = { Text("የቦታው ስም (አማርኛ) *") },
                placeholder = { Text("ለምሳሌ፡ ደብረ ምጥማቅ ቅድስት ማርያም") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_input_name_am"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            OutlinedTextField(
                value = nameEnglish,
                onValueChange = { nameEnglish = it },
                label = { Text("የቦታው ስም (English)") },
                placeholder = { Text("e.g. Saint Mary Church") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_input_name_en"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = denominationOrType,
                    onValueChange = { denominationOrType = it },
                    label = { Text("ዓይነት / ሥርዓት") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = centuryBuilt,
                    onValueChange = { centuryBuilt = it },
                    label = { Text("የተመሠረተበት ዘመን") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text("ከተማ (City) *") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = subCityOrZone,
                    onValueChange = { subCityOrZone = it },
                    label = { Text("ክፍለ ከተማ / ዞን") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            OutlinedTextField(
                value = descriptionAmharic,
                onValueChange = { descriptionAmharic = it },
                label = { Text("ታሪክና ዝርዝር መረጃ (Description)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp),
                shape = RoundedCornerShape(12.dp),
                maxLines = 4
            )

            // Section 2: Location & GPS (Google Maps)
            Text(
                text = "2. ካርታና የጂፒኤስ መገኛ (Google Maps Coordinates)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = addressAmharic,
                onValueChange = { addressAmharic = it },
                label = { Text("ሙሉ አድራሻ (Address in Ethiopia)") },
                leadingIcon = { Icon(Icons.Default.LocationOn, null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = latitudeText,
                    onValueChange = { latitudeText = it },
                    label = { Text("Latitude (ኬክሮስ)") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                OutlinedTextField(
                    value = longitudeText,
                    onValueChange = { longitudeText = it },
                    label = { Text("Longitude (ኬንትሮስ)") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }

            // Section 3: Programs & Schedule
            Text(
                text = "3. የጸሎትና የአምልኮ መርሐ ግብር (Program Schedule)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = programTitle,
                onValueChange = { programTitle = it },
                label = { Text("የመርሐ ግብሩ ስም") },
                leadingIcon = { Icon(Icons.Default.Schedule, null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = programDay,
                    onValueChange = { programDay = it },
                    label = { Text("ቀን (Day)") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = programTime,
                    onValueChange = { programTime = it },
                    label = { Text("ሰዓት (Time)") },
                    modifier = Modifier.weight(1.2f),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = feastName,
                    onValueChange = { feastName = it },
                    label = { Text("ዋና በዓል / ንግሥ") },
                    leadingIcon = { Icon(Icons.Default.CalendarMonth, null) },
                    modifier = Modifier.weight(1.2f),
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = feastDate,
                    onValueChange = { feastDate = it },
                    label = { Text("ቀን (Date)") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // Section 4: Leaders & Clergy Contacts
            Text(
                text = "4. የአስተዳዳሪ / መሪ አድራሻ (Leader Contacts)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = contactTitle,
                    onValueChange = { contactTitle = it },
                    label = { Text("ማዕረግ / ሓላፊነት") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = contactName,
                    onValueChange = { contactName = it },
                    label = { Text("ስም") },
                    leadingIcon = { Icon(Icons.Default.Person, null) },
                    modifier = Modifier.weight(1.3f),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            OutlinedTextField(
                value = contactPhone,
                onValueChange = { contactPhone = it },
                label = { Text("ስልክ ቁጥር (Phone Number)") },
                leadingIcon = { Icon(Icons.Default.Phone, null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )

            // Section 5: Church Image Picker
            Text(
                text = "5. ፎቶ ምረጥ (Select Image / Photo):",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(imagePresets) { (label, resId) ->
                    val isSelected = selectedImageRes == resId
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                        modifier = Modifier
                            .width(110.dp)
                            .clickable { selectedImageRes = resId }
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(90.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            ) {
                                Image(
                                    painter = painterResource(id = resId),
                                    contentDescription = label,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                if (isSelected) {
                                    Surface(
                                        shape = RoundedCornerShape(topStart = 0.dp, bottomEnd = 8.dp),
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            if (formError != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = formError!!,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Save Button
            Button(
                onClick = {
                    if (nameAmharic.isBlank()) {
                        formError = "እባክዎ የቦታውን ስም ያስገቡ!"
                        return@Button
                    }
                    if (city.isBlank()) {
                        formError = "እባክዎ ከተማውን ያስገቡ!"
                        return@Button
                    }

                    val lat = latitudeText.toDoubleOrNull() ?: 9.0300
                    val lng = longitudeText.toDoubleOrNull() ?: 38.7400

                    val newChurch = Church(
                        id = "custom_" + UUID.randomUUID().toString().take(8),
                        nameAmharic = nameAmharic.trim(),
                        nameEnglish = if (nameEnglish.isBlank()) nameAmharic.trim() else nameEnglish.trim(),
                        tradition = tradition,
                        denominationOrType = denominationOrType.trim(),
                        city = city.trim(),
                        subCityOrZone = subCityOrZone.trim(),
                        dioceseAmharic = diocese.trim(),
                        isHistoricOrMonastery = isHistoric,
                        centuryBuilt = centuryBuilt.trim(),
                        descriptionAmharic = if (descriptionAmharic.isBlank()) "በ${city} ከተማ የሚገኝ የ${denominationOrType} ቅዱስ ሥፍራ።" else descriptionAmharic.trim(),
                        addressAmharic = if (addressAmharic.isBlank()) "${city}፣ ኢትዮጵያ" else addressAmharic.trim(),
                        latitude = lat,
                        longitude = lng,
                        clergyContacts = listOf(
                            ClergyContact(
                                title = contactTitle.trim(),
                                name = contactName.trim(),
                                phoneNumber = contactPhone.trim(),
                                roleAmharic = "አስተዳደር"
                            )
                        ),
                        weeklyPrograms = listOf(
                            LiturgyProgram(
                                titleAmharic = programTitle.trim(),
                                timeAmharic = programTime.trim(),
                                dayOfWeek = programDay.trim(),
                                description = programDesc.trim(),
                                type = when (tradition) {
                                    ReligiousTradition.ORTHODOX -> ProgramType.LITURGY
                                    ReligiousTradition.PROTESTANT -> ProgramType.LITURGY
                                    ReligiousTradition.ISLAM -> ProgramType.JUMMAH
                                }
                            )
                        ),
                        annualFeasts = listOf(
                            TabotFeast(
                                saintNameAmharic = feastName.trim(),
                                ethiopianDate = feastDate.trim(),
                                gregorianDateApprox = "ዓመታዊ",
                                feastTitle = feastName.trim(),
                                description = "ምእመናን የሚሰበሰቡበት ዓመታዊ ታላቅ በዓል"
                            )
                        ),
                        sundaySchoolPrograms = emptyList(),
                        localImageDrawable = selectedImageRes,
                        distanceKmAddis = 0.0,
                        travelTipAmharic = if (travelTip.isBlank()) "በGoogle Maps አቅጣጫ በቀላሉ መድረስ ይቻላል።" else travelTip.trim()
                    )

                    onSavePlace(newChurch)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("admin_save_place_btn"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "በቤተ እምነት መዝግብ (Save Place)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
