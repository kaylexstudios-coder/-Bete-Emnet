package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Church
import com.example.data.model.ReligiousTradition
import com.example.data.remote.GeminiMapsService
import com.example.data.remote.MapsAiResponse
import com.example.data.repository.ChurchRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AppScreen {
    HOME,
    DETAIL,
    MAPS_AI,
    FAVORITES,
    CALENDAR,
    ADMIN_LOGIN,
    ADMIN_DASHBOARD,
    ADMIN_ADD_CHURCH
}

data class ChurchUiState(
    val currentScreen: AppScreen = AppScreen.HOME,
    val selectedChurch: Church? = null,
    val churches: List<Church> = emptyList(),
    val filteredChurches: List<Church> = emptyList(),
    val searchQuery: String = "",
    val selectedTradition: ReligiousTradition? = null,
    val selectedCity: String = "ሁሉንም",
    val onlyHistoric: Boolean = false,
    val onlyCathedrals: Boolean = false,
    val favoriteIds: Set<String> = setOf("lalibela_giyorgis", "eecmy_central", "anwar_mosque"),
    // Admin Portal State
    val isAdminLoggedIn: Boolean = false,
    val adminEmailInput: String = "",
    val adminPasswordInput: String = "",
    val adminLoginError: String? = null,
    val adminSuccessMessage: String? = null,
    // Gemini Google Maps Grounding State
    val mapsAiLoading: Boolean = false,
    val mapsAiQuery: String = "",
    val currentMapsAiResponse: MapsAiResponse? = null,
    val aiConversationHistory: List<Pair<String, MapsAiResponse>> = emptyList()
)

class ChurchViewModel(
    private val repository: ChurchRepository = ChurchRepository(),
    private val mapsService: GeminiMapsService = GeminiMapsService()
) : ViewModel() {

    companion object {
        const val ADMIN_EMAIL = "kaylexstudios@gmail.com"
        const val ADMIN_PASSWORD = "Liele1122@"
    }

    private val _uiState = MutableStateFlow(ChurchUiState())
    val uiState: StateFlow<ChurchUiState> = _uiState.asStateFlow()

    init {
        refreshChurches()
    }

    val cities: List<String> = repository.getCities()

    private fun refreshChurches() {
        val list = repository.getAllChurches()
        _uiState.update {
            it.copy(
                churches = list
            )
        }
        applyFilters()
    }

    fun onSearchQueryChanged(newQuery: String) {
        _uiState.update { it.copy(searchQuery = newQuery) }
        applyFilters()
    }

    fun onTraditionSelected(tradition: ReligiousTradition?) {
        _uiState.update { it.copy(selectedTradition = tradition) }
        applyFilters()
    }

    fun onCitySelected(city: String) {
        _uiState.update { it.copy(selectedCity = city) }
        applyFilters()
    }

    fun toggleHistoricFilter() {
        _uiState.update { it.copy(onlyHistoric = !it.onlyHistoric) }
        applyFilters()
    }

    fun toggleCathedralFilter() {
        _uiState.update { it.copy(onlyCathedrals = !it.onlyCathedrals) }
        applyFilters()
    }

    fun resetFilters() {
        _uiState.update {
            it.copy(
                searchQuery = "",
                selectedTradition = null,
                selectedCity = "ሁሉንም",
                onlyHistoric = false,
                onlyCathedrals = false
            )
        }
        applyFilters()
    }

    private fun applyFilters() {
        val state = _uiState.value
        val filtered = repository.searchAndFilter(
            query = state.searchQuery,
            selectedTradition = state.selectedTradition,
            selectedCity = state.selectedCity,
            onlyHistoric = state.onlyHistoric,
            onlyCathedrals = state.onlyCathedrals
        )
        _uiState.update { it.copy(filteredChurches = filtered) }
    }

    fun toggleFavorite(churchId: String) {
        _uiState.update { current ->
            val newFavorites = if (current.favoriteIds.contains(churchId)) {
                current.favoriteIds - churchId
            } else {
                current.favoriteIds + churchId
            }
            current.copy(favoriteIds = newFavorites)
        }
    }

    fun selectChurch(church: Church) {
        _uiState.update {
            it.copy(
                selectedChurch = church,
                currentScreen = AppScreen.DETAIL
            )
        }
    }

    fun navigateTo(screen: AppScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun navigateBack() {
        _uiState.update {
            when (it.currentScreen) {
                AppScreen.DETAIL, AppScreen.MAPS_AI, AppScreen.FAVORITES, AppScreen.CALENDAR, AppScreen.ADMIN_LOGIN -> {
                    it.copy(currentScreen = AppScreen.HOME)
                }
                AppScreen.ADMIN_ADD_CHURCH -> {
                    it.copy(currentScreen = AppScreen.ADMIN_DASHBOARD)
                }
                AppScreen.ADMIN_DASHBOARD -> {
                    it.copy(currentScreen = AppScreen.HOME)
                }
                AppScreen.HOME -> it
            }
        }
    }

    // --- Admin Authentication & Content Management ---

    fun onAdminEmailChanged(email: String) {
        _uiState.update { it.copy(adminEmailInput = email, adminLoginError = null) }
    }

    fun onAdminPasswordChanged(password: String) {
        _uiState.update { it.copy(adminPasswordInput = password, adminLoginError = null) }
    }

    fun loginAdmin(): Boolean {
        val email = _uiState.value.adminEmailInput.trim()
        val password = _uiState.value.adminPasswordInput.trim()

        return if (email.equals(ADMIN_EMAIL, ignoreCase = true) && password == ADMIN_PASSWORD) {
            _uiState.update {
                it.copy(
                    isAdminLoggedIn = true,
                    adminLoginError = null,
                    currentScreen = AppScreen.ADMIN_DASHBOARD
                )
            }
            true
        } else {
            _uiState.update {
                it.copy(
                    adminLoginError = "የተሳሳተ ኢሜይል ወይም የይለፍ ቃል! እባክዎ በትክክል ያስገቡ።"
                )
            }
            false
        }
    }

    fun logoutAdmin() {
        _uiState.update {
            it.copy(
                isAdminLoggedIn = false,
                adminPasswordInput = "",
                currentScreen = AppScreen.HOME
            )
        }
    }

    fun addNewPlaceOfWorship(church: Church) {
        repository.addChurch(church)
        refreshChurches()
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.ADMIN_DASHBOARD,
                adminSuccessMessage = "አዲሱ የ${church.denominationOrType} ${church.nameAmharic} በተሳካ ሁኔታ ተመዝግቧል!"
            )
        }
    }

    fun deletePlaceOfWorship(id: String) {
        repository.deleteChurch(id)
        refreshChurches()
    }

    fun clearAdminSuccessMessage() {
        _uiState.update { it.copy(adminSuccessMessage = null) }
    }

    // --- AI Maps Advisor ---

    fun updateMapsAiQuery(query: String) {
        _uiState.update { it.copy(mapsAiQuery = query) }
    }

    fun askMapsAdvisor(query: String, church: Church? = null) {
        if (query.isBlank()) return

        val contextStr = church?.let {
            "${it.nameAmharic} (${it.nameEnglish}), Tradition: ${it.tradition.name}, City: ${it.city}, Subcity: ${it.subCityOrZone}, Lat: ${it.latitude}, Lng: ${it.longitude}"
        }

        _uiState.update {
            it.copy(
                mapsAiLoading = true,
                mapsAiQuery = ""
            )
        }

        viewModelScope.launch {
            val response = mapsService.queryMapsGrounding(query, contextStr)
            _uiState.update { current ->
                val updatedHistory = current.aiConversationHistory + (query to response)
                current.copy(
                    mapsAiLoading = false,
                    currentMapsAiResponse = response,
                    aiConversationHistory = updatedHistory
                )
            }
        }
    }
}
