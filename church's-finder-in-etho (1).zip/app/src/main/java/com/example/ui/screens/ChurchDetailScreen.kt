package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Church
import com.example.data.model.ClergyContact
import com.example.data.model.LiturgyProgram
import com.example.data.model.ProgramType
import com.example.data.model.ReligiousTradition
import com.example.data.model.SundaySchoolProgram
import com.example.data.model.TabotFeast
import com.example.ui.components.DirectionsLauncher
import com.example.ui.components.ReligiousEmblemIcon

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChurchDetailScreen(
    church: Church,
    isFavorite: Boolean,
    onBackClick: () -> Unit,
    onFavoriteToggle: () -> Unit,
    onAskAiMapsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    BackHandler { onBackClick() }

    var selectedTabIndex by remember { mutableIntStateOf(0) }

    val tabTitles = when (church.tradition) {
        ReligiousTradition.ORTHODOX -> listOf(
            "አጠቃላይና ታሪክ",
            "የቅዳሴ መርሐ ግብር",
            "የታቦት ንግሥ በዓላት",
            "የካህናት አድራሻ",
            "ካርታና አቅጣጫ"
        )
        ReligiousTradition.PROTESTANT -> listOf(
            "አጠቃላይና ታሪክ",
            "የአምልኮ መርሐ ግብር",
            "ዓመታዊ ኮንፈረንስ",
            "የፓስተሮች አድራሻ",
            "ካርታና አቅጣጫ"
        )
        ReligiousTradition.ISLAM -> listOf(
            "አጠቃላይና ታሪክ",
            "የሰላትና ኹጥባ ሰዓት",
            "የዒድና ዓመታዊ በዓላት",
            "የኢማሞች አድራሻ",
            "ካርታና አቅጣጫ"
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = church.nameAmharic,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ተመለስ"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onFavoriteToggle,
                        modifier = Modifier.testTag("detail_favorite_button")
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "ተወዳጅ",
                            tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(
                        onClick = { DirectionsLauncher.shareChurchInfo(context, church) },
                        modifier = Modifier.testTag("detail_share_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "አጋራ"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Hero Photo Section
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                ) {
                    if (church.localImageDrawable != null) {
                        Image(
                            painter = painterResource(id = church.localImageDrawable),
                            contentDescription = church.nameAmharic,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        val gradientColors = when (church.tradition) {
                            ReligiousTradition.ORTHODOX -> listOf(
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.surfaceVariant
                            )
                            ReligiousTradition.PROTESTANT -> listOf(
                                Color(0xFFDCEAF7),
                                Color(0xFFC7DDF2)
                            )
                            ReligiousTradition.ISLAM -> listOf(
                                Color(0xFFD4EFE0),
                                Color(0xFFBFE0CE)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Brush.verticalGradient(gradientColors)),
                            contentAlignment = Alignment.Center
                        ) {
                            ReligiousEmblemIcon(
                                tradition = church.tradition,
                                size = 64.dp,
                                tint = when (church.tradition) {
                                    ReligiousTradition.ORTHODOX -> MaterialTheme.colorScheme.primary
                                    ReligiousTradition.PROTESTANT -> Color(0xFF1E5B94)
                                    ReligiousTradition.ISLAM -> Color(0xFF1E7E34)
                                }
                            )
                        }
                    }

                    // Scrim gradient
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    0.0f to Color.Black.copy(alpha = 0.3f),
                                    0.5f to Color.Transparent,
                                    1.0f to Color.Black.copy(alpha = 0.75f)
                                )
                            )
                    )

                    // Hero Text overlay
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val badgeColor = when (church.tradition) {
                                ReligiousTradition.ORTHODOX -> MaterialTheme.colorScheme.primary
                                ReligiousTradition.PROTESTANT -> Color(0xFF1E5B94)
                                ReligiousTradition.ISLAM -> Color(0xFF1E7E34)
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = badgeColor
                            ) {
                                Text(
                                    text = church.denominationOrType,
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.secondary
                            ) {
                                Text(
                                    text = church.city,
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = church.nameAmharic,
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = church.nameEnglish,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            // Quick Action Buttons (Get Directions & Ask Maps AI)
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { DirectionsLauncher.launchGoogleMapsDirections(context, church) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("detail_primary_directions_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Directions, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("አቅጣጫ (Maps)", fontWeight = FontWeight.Bold)
                        }

                        FilledTonalButton(
                            onClick = onAskAiMapsClick,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("detail_ask_ai_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Map, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("የመንገድ መረጃ ረዳት", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Tab Navigation
            item {
                ScrollableTabRow(
                    selectedTabIndex = selectedTabIndex,
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = { selectedTabIndex = index },
                            text = {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTabIndex == index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        )
                    }
                }
            }

            // Tab Contents
            when (selectedTabIndex) {
                0 -> {
                    // Overview & History Tab
                    item {
                        OverviewHistorySection(church = church)
                    }
                }
                1 -> {
                    // Liturgy / Worship / Prayer Programs Tab
                    item {
                        LiturgyProgramsSection(church = church)
                    }
                }
                2 -> {
                    // Annual Feasts / Conferences / Eid Tab
                    item {
                        TabotFeastsSection(church = church)
                    }
                }
                3 -> {
                    // Leaders & Clergy Contacts Tab
                    item {
                        ClergyContactsSection(church = church)
                    }
                }
                4 -> {
                    // Map Preview & Navigation Tab
                    item {
                        MapPreviewSection(church = church)
                    }
                }
            }
        }
    }
}

@Composable
private fun OverviewHistorySection(church: Church) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quick Facts Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "መሠረታዊ መረጃ (Quick Facts)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(12.dp))
                FactRow(label = "ዓይነት / ሥርዓት:", value = church.denominationOrType)
                FactRow(label = "ከተማና ክልል:", value = "${church.city} (${church.subCityOrZone})")
                FactRow(label = "የተመሠረተበት ዘመን:", value = church.centuryBuilt)
                if (church.patronSaint.isNotBlank()) {
                    FactRow(label = "ስያሜ / ጠባቂ:", value = church.patronSaint)
                }
                FactRow(
                    label = "የርቀት ግምት ከአዲስ አበባ:",
                    value = if (church.distanceKmAddis == 0.0) "በአዲስ አበባ ውስጥ ይገኛል" else "${church.distanceKmAddis.toInt()} ኪ.ሜ"
                )
            }
        }

        // History & Heritage
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ReligiousEmblemIcon(
                        tradition = church.tradition,
                        size = 24.dp,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ታሪክና ማብራሪያ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = church.descriptionAmharic,
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 24.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Travel Tip
        if (church.travelTipAmharic.isNotBlank()) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ለጎብኚዎችና ለምእመናን የጉዞ ምክር",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = church.travelTipAmharic,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiturgyProgramsSection(church: Church) {
    val sectionHeader = when (church.tradition) {
        ReligiousTradition.ORTHODOX -> "ሳምንታዊ የቅዳሴና የጸሎት መርሐ ግብር"
        ReligiousTradition.PROTESTANT -> "ሳምንታዊ የአምልኮና የትምህርት መርሐ ግብር"
        ReligiousTradition.ISLAM -> "የአምስቱ ወቅት ሰላቶችና የጁምዓ መርሐ ግብር"
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = sectionHeader,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        church.weeklyPrograms.forEach { program ->
            ProgramCard(program = program)
        }

        if (church.sundaySchoolPrograms.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            val youthTitle = when (church.tradition) {
                ReligiousTradition.ORTHODOX -> "የሰንበት ትምህርት ቤት ጉባኤ"
                ReligiousTradition.PROTESTANT -> "የሕፃናትና የወጣቶች ትምህርት ቤት"
                ReligiousTradition.ISLAM -> "የመድረሳና የቁርኣን ቂርዓት ትምህርት"
            }

            Text(
                text = youthTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )

            church.sundaySchoolPrograms.forEach { ssp ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = ssp.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "ሰዓት: ${ssp.schedule}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgramCard(program: LiturgyProgram) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = when (program.type) {
                    ProgramType.LITURGY -> MaterialTheme.colorScheme.primaryContainer
                    ProgramType.PRAYER_SERVICE -> MaterialTheme.colorScheme.secondaryContainer
                    ProgramType.MAHLET -> MaterialTheme.colorScheme.tertiaryContainer
                    ProgramType.KIDAN -> MaterialTheme.colorScheme.surfaceVariant
                    ProgramType.JUMMAH -> Color(0xFFD6EDE0)
                    ProgramType.SUNDAY_SCHOOL -> MaterialTheme.colorScheme.surfaceVariant
                },
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = when (program.type) {
                            ProgramType.LITURGY -> Icons.Default.Schedule
                            ProgramType.PRAYER_SERVICE -> Icons.Default.Star
                            ProgramType.MAHLET -> Icons.Default.CalendarMonth
                            ProgramType.KIDAN -> Icons.Default.Schedule
                            ProgramType.JUMMAH -> Icons.Default.Schedule
                            ProgramType.SUNDAY_SCHOOL -> Icons.Default.People
                        },
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = program.titleAmharic,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${program.dayOfWeek} • ${program.timeAmharic}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                if (program.description.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = program.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun TabotFeastsSection(church: Church) {
    val sectionTitle = when (church.tradition) {
        ReligiousTradition.ORTHODOX -> "ዓመታዊ የታቦት ንግሥ በዓላት (Tabot Feasts)"
        ReligiousTradition.PROTESTANT -> "ዓመታዊ ኮንፈረንሶችና በዓላት (Conferences & Holidays)"
        ReligiousTradition.ISLAM -> "የዒድና ዓመታዊ የእስልምና በዓላት (Eid Festivals)"
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = sectionTitle,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        church.annualFeasts.forEach { feast ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ReligiousEmblemIcon(
                                tradition = church.tradition,
                                size = 26.dp,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = feast.saintNameAmharic,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = feast.feastTitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = feast.ethiopianDate,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = feast.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "ቀን ግምት: ${feast.gregorianDateApprox}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        }
    }
}

@Composable
private fun ClergyContactsSection(church: Church) {
    val context = LocalContext.current
    val headerText = when (church.tradition) {
        ReligiousTradition.ORTHODOX -> "የደብሩ አስተዳዳሪና የካህናት አድራሻ"
        ReligiousTradition.PROTESTANT -> "የመጋቢዎችና የፓስተሮች አድራሻ"
        ReligiousTradition.ISLAM -> "የኢማሞችና የመጅሊሱ አስተዳደር አድራሻ"
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = headerText,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        church.clergyContacts.forEach { contact ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = when (church.tradition) {
                                    ReligiousTradition.ORTHODOX -> "ካህን"
                                    ReligiousTradition.PROTESTANT -> "መጋቢ"
                                    ReligiousTradition.ISLAM -> "ኢማም"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = contact.title,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = contact.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = contact.phoneNumber,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    FilledTonalButton(
                        onClick = { DirectionsLauncher.dialPhoneNumber(context, contact.phoneNumber) },
                        shape = CircleShape,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "ደውል",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MapPreviewSection(church: Church) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "የጂፒኤስ ካርታና አቅጣጫ (Google Maps Preview)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(42.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = church.nameAmharic,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${church.latitude}° N, ${church.longitude}° E",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "አድራሻ: ${church.addressAmharic}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { DirectionsLauncher.launchGoogleMapsDirections(context, church) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Navigation, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("አቅጣጫ አስጀምር")
                    }

                    OutlinedButton(
                        onClick = { DirectionsLauncher.openLocationOnMap(context, church) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Map, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("በካርታ ክፈት")
                    }
                }
            }
        }
    }
}

@Composable
private fun FactRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
