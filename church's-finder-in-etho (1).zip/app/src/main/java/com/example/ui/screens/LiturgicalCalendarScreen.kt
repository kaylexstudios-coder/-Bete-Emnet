package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Church
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.EthiopianCrossIcon

data class MonthlyFeastDay(
    val dayNumber: Int,
    val saintName: String,
    val significance: String,
    val majorChurches: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiturgicalCalendarScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBackClick() }

    val monthlyFeasts = listOf(
        MonthlyFeastDay(7, "ቅድስት ሥላሴ", "የአብ የወልድ የመንፈስ ቅዱስ ምስጋና", "መንበረ ፀባዖት ካቴድራል፣ ደብረ ብርሃን ሥላሴ ጎንደር"),
        MonthlyFeastDay(12, "ሊቀ መላእክት ቅዱስ ሚካኤል", "የዋህ መልአክ የመላእክት አለቃ", "የካ ሚካኤል፣ ደብረ ታቦር፣ ወሎ ሚካኤል"),
        MonthlyFeastDay(19, "ሊቀ መላእክት ቅዱስ ገብርኤል", "አብሳሪው መልአክ፣ የቂርቆስ ረዳት", "ቁልቢ ገብርኤል፣ ሐዋሳ ደብረ ምሕረት"),
        MonthlyFeastDay(21, "እመቤታችን ቅድስት ድንግል ማርያም (ጽዮን)", "ታቦተ ጽዮን፣ ኅዳር ጽዮን", "አክሱም ጽዮን ማርያም፣ ደብረ ማርያም ጣና"),
        MonthlyFeastDay(23, "ሰማዕቱ ቅዱስ ጊዮርጊስ", "የልዳው ኮከብ፣ መክብበ ሰማዕታት", "ቤተ ጊዮርጊስ ላሊበላ፣ አራዳ ጊዮርጊስ"),
        MonthlyFeastDay(24, "ጻድቁ አቡነ ተክለ ሃይማኖት", "ኢትዮጵያዊው ጻድቅ፣ ሐዲስ ሐዋርያ", "ደብረ ሊባኖስ ገዳም"),
        MonthlyFeastDay(27, "መድኃኔዓለም (ኢየሱስ ክርስቶስ)", "የዓለም መድኃኒት፣ የዘለዓለም ሕይወት", "ቦሌ መድኃኔዓለም፣ መርካቶ መድኃኔዓለም"),
        MonthlyFeastDay(29, "በዓለ ወልድ / ገና", "የጌታችን የመወለዱ መታሰቢያ", "ላሊበላ ቤተ አማኑኤል፣ ሰሜን ሸዋ")
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "የኢትዮጵያ ኦርቶዶክስ ተዋሕዶ በዓላት",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("calendar_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ተመለስ"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        EthiopianCrossIcon(size = 38.dp, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "ወርሃዊና ዓመታዊ የታቦት በዓላት",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "በኢትዮጵያ ኦርቶዶክስ ተዋሕዶ ቤተክርስቲያን በየወሩ የሚከበሩ ዋና ዋና የቅዱሳን በዓላት ዝርዝር።",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "የወሩ ጽላት በዓላት (Monthly Feast Days)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            items(monthlyFeasts) { feast ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "${feast.dayNumber}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = feast.saintName,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = feast.significance,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "ዋና አድባራት: ${feast.majorChurches}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
