package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.ReligiousTradition

@Composable
fun ReligiousEmblemIcon(
    tradition: ReligiousTradition,
    modifier: Modifier = Modifier,
    size: Dp = 28.dp,
    tint: Color = MaterialTheme.colorScheme.primary
) {
    when (tradition) {
        ReligiousTradition.ORTHODOX -> EthiopianCrossIcon(modifier = modifier, size = size, tint = tint)
        ReligiousTradition.PROTESTANT -> ProtestantCrossIcon(modifier = modifier, size = size, tint = tint)
        ReligiousTradition.ISLAM -> IslamicCrescentIcon(modifier = modifier, size = size, tint = tint)
    }
}

@Composable
fun EthiopianCrossIcon(
    modifier: Modifier = Modifier,
    size: Dp = 28.dp,
    tint: Color = MaterialTheme.colorScheme.primary
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height
            val strokeW = w * 0.12f

            // Central vertical bar
            drawLine(
                color = tint,
                start = Offset(w * 0.5f, h * 0.08f),
                end = Offset(w * 0.5f, h * 0.92f),
                strokeWidth = strokeW,
                cap = StrokeCap.Round
            )

            // Horizontal cross beam
            drawLine(
                color = tint,
                start = Offset(w * 0.15f, h * 0.38f),
                end = Offset(w * 0.85f, h * 0.38f),
                strokeWidth = strokeW,
                cap = StrokeCap.Round
            )

            // Top decorative Lalibela diamond
            val topPath = Path().apply {
                moveTo(w * 0.5f, h * 0.05f)
                lineTo(w * 0.62f, h * 0.16f)
                lineTo(w * 0.5f, h * 0.22f)
                lineTo(w * 0.38f, h * 0.16f)
                close()
            }
            drawPath(topPath, color = tint)

            // Left finial
            val leftPath = Path().apply {
                moveTo(w * 0.12f, h * 0.38f)
                lineTo(w * 0.22f, h * 0.30f)
                lineTo(w * 0.26f, h * 0.38f)
                lineTo(w * 0.22f, h * 0.46f)
                close()
            }
            drawPath(leftPath, color = tint)

            // Right finial
            val rightPath = Path().apply {
                moveTo(w * 0.88f, h * 0.38f)
                lineTo(w * 0.78f, h * 0.30f)
                lineTo(w * 0.74f, h * 0.38f)
                lineTo(w * 0.78f, h * 0.46f)
                close()
            }
            drawPath(rightPath, color = tint)

            // Bottom base steps
            drawLine(
                color = tint,
                start = Offset(w * 0.35f, h * 0.85f),
                end = Offset(w * 0.65f, h * 0.85f),
                strokeWidth = strokeW * 0.8f,
                cap = StrokeCap.Round
            )

            // Central concentric circle halo
            drawCircle(
                color = tint,
                radius = w * 0.22f,
                center = Offset(w * 0.5f, h * 0.38f),
                style = Stroke(width = strokeW * 0.6f)
            )
        }
    }
}

@Composable
fun ProtestantCrossIcon(
    modifier: Modifier = Modifier,
    size: Dp = 28.dp,
    tint: Color = MaterialTheme.colorScheme.primary
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height
            val strokeW = w * 0.14f

            // Clean, elegant Evangelical Latin Cross
            drawLine(
                color = tint,
                start = Offset(w * 0.5f, h * 0.08f),
                end = Offset(w * 0.5f, h * 0.92f),
                strokeWidth = strokeW,
                cap = StrokeCap.Round
            )

            drawLine(
                color = tint,
                start = Offset(w * 0.2f, h * 0.36f),
                end = Offset(w * 0.8f, h * 0.36f),
                strokeWidth = strokeW,
                cap = StrokeCap.Round
            )

            // Subtle gentle radiant light arcs behind the cross
            drawCircle(
                color = tint.copy(alpha = 0.35f),
                radius = w * 0.26f,
                center = Offset(w * 0.5f, h * 0.36f),
                style = Stroke(width = strokeW * 0.4f)
            )
        }
    }
}

@Composable
fun IslamicCrescentIcon(
    modifier: Modifier = Modifier,
    size: Dp = 28.dp,
    tint: Color = Color(0xFF1E7E34) // Traditional deep Islamic emerald green
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height

            // Crescent outer and inner arc path
            val crescentPath = Path().apply {
                moveTo(w * 0.68f, h * 0.15f)
                cubicTo(
                    w * 0.2f, h * 0.15f,
                    w * 0.1f, h * 0.85f,
                    w * 0.68f, h * 0.85f
                )
                cubicTo(
                    w * 0.32f, h * 0.78f,
                    w * 0.32f, h * 0.22f,
                    w * 0.68f, h * 0.15f
                )
                close()
            }
            drawPath(crescentPath, color = tint)

            // Star placed beside crescent
            val starPath = Path().apply {
                val cx = w * 0.68f
                val cy = h * 0.46f
                val r = w * 0.12f
                val innerR = r * 0.45f
                for (i in 0 until 5) {
                    val angle = (i * 72.0 - 18.0) * Math.PI / 180.0
                    val nextAngle = (angle + 36.0 * Math.PI / 180.0)
                    val x1 = cx + (r * Math.cos(angle)).toFloat()
                    val y1 = cy + (r * Math.sin(angle)).toFloat()
                    val x2 = cx + (innerR * Math.cos(nextAngle)).toFloat()
                    val y2 = cy + (innerR * Math.sin(nextAngle)).toFloat()
                    if (i == 0) moveTo(x1, y1) else lineTo(x1, y1)
                    lineTo(x2, y2)
                }
                close()
            }
            drawPath(starPath, color = tint)
        }
    }
}
