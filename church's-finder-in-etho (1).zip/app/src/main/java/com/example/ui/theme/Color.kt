package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Ethiopian Orthodox Ecclesiastical Colors
val GoldPrimary = Color(0xFFB8860B)
val GoldLight = Color(0xFFDFB15B)
val GoldDark = Color(0xFF8B6508)
val GoldContainerLight = Color(0xFFFBEFD1)
val OnGoldContainerLight = Color(0xFF3E2800)

val CrimsonSecondary = Color(0xFF8E2829)
val CrimsonSecondaryLight = Color(0xFFFFDAD6)
val CrimsonContainerLight = Color(0xFFFFDAD6)
val OnCrimsonContainerLight = Color(0xFF3B080B)

val EmeraldTertiary = Color(0xFF1E5B3A)
val EmeraldContainerLight = Color(0xFFB8F3C7)
val OnEmeraldContainerLight = Color(0xFF002111)

val ParchmentBackground = Color(0xFFFBF8F1)
val ParchmentSurface = Color(0xFFFDFBF7)
val SurfaceVariantLight = Color(0xFFEFE9DC)
val OnSurfaceLight = Color(0xFF1F1B16)
val OnSurfaceVariantLight = Color(0xFF4C453B)
val OutlineLight = Color(0xFF7E7569)

// Dark Theme Variants
val GoldPrimaryDark = Color(0xFFE8C26E)
val GoldContainerDark = Color(0xFF4E3700)
val OnGoldContainerDark = Color(0xFFFFDF9E)

val CrimsonSecondaryDark = Color(0xFFFFB3AC)
val CrimsonContainerDark = Color(0xFF711216)
val OnCrimsonContainerDark = Color(0xFFFFDAD6)

val EmeraldTertiaryDark = Color(0xFF9CD6AC)
val EmeraldContainerDark = Color(0xFF00522B)

val DarkBackground = Color(0xFF151311)
val DarkSurface = Color(0xFF1C1A17)
val SurfaceVariantDark = Color(0xFF464036)
val OnSurfaceDark = Color(0xFFEDE0D4)
val OnSurfaceVariantDark = Color(0xFFCFC4B5)
val OutlineDark = Color(0xFF988E81)
