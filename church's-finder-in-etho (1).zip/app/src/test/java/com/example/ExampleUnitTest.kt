package com.example

import com.example.data.model.Church
import com.example.data.model.ReligiousTradition
import com.example.data.repository.ChurchRepository
import com.example.ui.viewmodel.ChurchViewModel
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    private val repository = ChurchRepository()

    @Test
    fun churchesList_isNotEmpty() {
        val places = repository.getAllChurches()
        assertTrue("Churches & Mosques list should not be empty", places.isNotEmpty())
        assertTrue("Should contain at least 8 places", places.size >= 8)
    }

    @Test
    fun churchById_findsLalibela() {
        val church = repository.getChurchById("lalibela_giyorgis")
        assertNotNull(church)
        assertEquals("ቤተ ጊዮርጊስ (ላሊበላ)", church?.nameAmharic)
        assertEquals(ReligiousTradition.ORTHODOX, church?.tradition)
        assertTrue(church!!.isHistoricOrMonastery)
    }

    @Test
    fun churchById_findsProtestantMekaneYesus() {
        val church = repository.getChurchById("eecmy_central")
        assertNotNull(church)
        assertEquals(ReligiousTradition.PROTESTANT, church?.tradition)
        assertTrue(church!!.nameAmharic.contains("መካነ ኢየሱስ"))
    }

    @Test
    fun churchById_findsGrandAnwarMosque() {
        val mosque = repository.getChurchById("anwar_mosque")
        assertNotNull(mosque)
        assertEquals(ReligiousTradition.ISLAM, mosque?.tradition)
        assertTrue(mosque!!.nameAmharic.contains("አንዋር"))
        assertEquals("አዲስ አበባ", mosque.city)
    }

    @Test
    fun admin_credentialsValidation() {
        assertEquals("kaylexstudios@gmail.com", ChurchViewModel.ADMIN_EMAIL)
        assertEquals("Liele1122@", ChurchViewModel.ADMIN_PASSWORD)
    }

    @Test
    fun admin_canAddAndRetrieveNewPlace() {
        val customChurch = Church(
            id = "test_church_123",
            nameAmharic = "አዲስ የተመዘገበ ቤተክርስቲያን",
            nameEnglish = "Test Newly Added Church",
            tradition = ReligiousTradition.ORTHODOX,
            denominationOrType = "ኦርቶዶክስ ተዋሕዶ",
            dioceseAmharic = "አዲስ አበባ",
            subCityOrZone = "ቦሌ",
            city = "አዲስ አበባ",
            isHistoricOrMonastery = false,
            centuryBuilt = "2015 ዓ.ም",
            descriptionAmharic = "በአስተዳዳሪ የተመዘገበ አዲስ ቤተክርስቲያን",
            latitude = 9.0100,
            longitude = 38.7600,
            addressAmharic = "ቦሌ፣ አዲስ አበባ",
            clergyContacts = emptyList(),
            weeklyPrograms = emptyList(),
            annualFeasts = emptyList(),
            sundaySchoolPrograms = emptyList()
        )

        val initialCount = repository.getAllChurches().size
        repository.addChurch(customChurch)
        assertEquals(initialCount + 1, repository.getAllChurches().size)

        val retrieved = repository.getChurchById("test_church_123")
        assertNotNull(retrieved)
        assertEquals("አዲስ የተመዘገበ ቤተክርስቲያን", retrieved?.nameAmharic)

        repository.deleteChurch("test_church_123")
        assertEquals(initialCount, repository.getAllChurches().size)
    }
}
